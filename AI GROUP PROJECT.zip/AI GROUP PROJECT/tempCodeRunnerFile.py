
        self.btn_hard = Button(592, 400, 120, 50, "HARD", (204, 34, 0), (230, 60, 30))
        self.btn_start = Button(437, 510, 150, 55, "START", (34, 139, 34), (50, 170, 50))
        
        # 2. Instruction Screen States
        self.btn_lets_cook = Button(330, 570, 200, 55, "Let's Cook!", (34, 139, 34), (50, 170, 50))
        self.btn_repeat_instr = Button(560, 570, 240, 55, "Hear Again 🔊", (30, 77, 140), (50, 100, 180))
        