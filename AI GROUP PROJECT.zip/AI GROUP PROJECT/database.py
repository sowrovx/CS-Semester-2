# database.py
import sqlite3
import csv
import os
import datetime

DB_FILE = "chef_kitchen.db"

def get_connection():
    """Returns a connection to the SQLite database."""
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Creates all 4 tables if they do not exist yet."""
    conn = get_connection()
    cursor = conn.cursor()
    
    # Enable foreign keys
    cursor.execute("PRAGMA foreign_keys = ON;")
    
    # 1. players table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS players (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL,
        age INTEGER DEFAULT 5,
        created_date TEXT NOT NULL
    );
    """)
    
    # 2. game_sessions table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS game_sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        player_id INTEGER NOT NULL,
        level INTEGER NOT NULL,
        score INTEGER DEFAULT 0,
        total_questions INTEGER DEFAULT 0,
        correct_answers INTEGER DEFAULT 0,
        mistakes INTEGER DEFAULT 0,
        stars_earned INTEGER DEFAULT 0,
        timestamp TEXT NOT NULL,
        FOREIGN KEY (player_id) REFERENCES players(id) ON DELETE CASCADE
    );
    """)
    
    # 3. mistake_logs table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS mistake_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id INTEGER NOT NULL,
        sentence_attempted TEXT NOT NULL,
        user_answer TEXT NOT NULL,
        correct_answer TEXT NOT NULL,
        hint_given INTEGER DEFAULT 0,
        timestamp TEXT NOT NULL,
        FOREIGN KEY (session_id) REFERENCES game_sessions(id) ON DELETE CASCADE
    );
    """)
    
    # 4. progress table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS progress (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        player_id INTEGER UNIQUE NOT NULL,
        current_level INTEGER DEFAULT 1,
        total_score INTEGER DEFAULT 0,
        games_played INTEGER DEFAULT 0,
        FOREIGN KEY (player_id) REFERENCES players(id) ON DELETE CASCADE
    );
    """)
    
    conn.commit()
    conn.close()

def get_or_create_player(name):
    """
    Checks if a player with name exists.
    If yes, returns their row. If no, creates them and returns the row.
    """
    name = name.strip()
    if not name:
        return None
        
    conn = get_connection()
    cursor = conn.cursor()
    
    cursor.execute("SELECT * FROM players WHERE name = ?", (name,))
    player = cursor.fetchone()
    
    if player:
        player_id = player['id']
    else:
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        cursor.execute("INSERT INTO players (name, age, created_date) VALUES (?, 5, ?)", (name, now))
        player_id = cursor.lastrowid
        # Also initialize empty progress
        cursor.execute("INSERT OR IGNORE INTO progress (player_id, current_level, total_score, games_played) VALUES (?, 1, 0, 0)", (player_id,))
        conn.commit()
        
        cursor.execute("SELECT * FROM players WHERE id = ?", (player_id,))
        player = cursor.fetchone()
        
    conn.close()
    return dict(player)

def create_session(player_id, level):
    """Creates a new session row in game_sessions, returns session ID."""
    conn = get_connection()
    cursor = conn.cursor()
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cursor.execute("""
        INSERT INTO game_sessions (player_id, level, score, total_questions, correct_answers, mistakes, stars_earned, timestamp)
        VALUES (?, ?, 0, 0, 0, 0, 0, ?)
    """, (player_id, level, now))
    session_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return session_id

def update_session(sid, score, total_questions, correct_answers, mistakes, stars_earned):
    """Updates the session row with latest stats."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        UPDATE game_sessions
        SET score = ?, total_questions = ?, correct_answers = ?, mistakes = ?, stars_earned = ?
        WHERE id = ?
    """, (score, total_questions, correct_answers, mistakes, stars_earned, sid))
    conn.commit()
    conn.close()

def log_mistake(sid, sentence_attempted, user_answer, correct_answer, hint_given):
    """Logs a mistake into the mistake_logs table."""
    conn = get_connection()
    cursor = conn.cursor()
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cursor.execute("""
        INSERT INTO mistake_logs (session_id, sentence_attempted, user_answer, correct_answer, hint_given, timestamp)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (sid, sentence_attempted, user_answer, correct_answer, int(hint_given), now))
    conn.commit()
    conn.close()

def update_progress(player_id, level, score):
    """Updates all-time totals for the player in the progress table."""
    conn = get_connection()
    cursor = conn.cursor()
    
    # Check if entry exists
    cursor.execute("SELECT * FROM progress WHERE player_id = ?", (player_id,))
    row = cursor.fetchone()
    
    if row:
        new_games = row['games_played'] + 1
        new_score = row['total_score'] + score
        new_level = max(row['current_level'], level)
        cursor.execute("""
            UPDATE progress
            SET current_level = ?, total_score = ?, games_played = ?
            WHERE player_id = ?
        """, (new_level, new_score, new_games, player_id))
    else:
        cursor.execute("""
            INSERT INTO progress (player_id, current_level, total_score, games_played)
            VALUES (?, ?, ?, 1)
        """, (player_id, level, score))
        
    conn.commit()
    conn.close()

def get_high_scores(limit=4):
    """Returns top N players sorted by total_score."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT p.name, pr.total_score, pr.current_level, pr.games_played
        FROM progress pr
        JOIN players p ON pr.player_id = p.id
        ORDER BY pr.total_score DESC
        LIMIT ?
    """, (limit,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]

def get_session_stats(session_id):
    """Returns all stats for one session."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT gs.*, p.name as player_name
        FROM game_sessions gs
        JOIN players p ON gs.player_id = p.id
        WHERE gs.id = ?
    """, (session_id,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None

def get_mistake_patterns(player_id):
    """
    Loads historical mistake patterns from previous sessions for this player.
    Returns a dictionary of {word: mistake_count} where the word was placed in the wrong position.
    """
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT ml.user_answer, ml.correct_answer
        FROM mistake_logs ml
        JOIN game_sessions gs ON ml.session_id = gs.id
        WHERE gs.player_id = ?
    """, (player_id,))
    rows = cursor.fetchall()
    conn.close()
    
    mistake_counts = {}
    for r in rows:
        user_words = r['user_answer'].strip().split()
        corr_words = r['correct_answer'].strip().split()
        # Find which words were in the wrong position
        for i, word in enumerate(user_words):
            if i < len(corr_words):
                # If word doesn't match the word at correct slot
                if word != corr_words[i]:
                    mistake_counts[word] = mistake_counts.get(word, 0) + 1
                    
    return mistake_counts

def export_csv(session_id, name):
    """
    Writes a CSV report file containing session details and mistake logs.
    Returns the file path.
    """
    session = get_session_stats(session_id)
    if not session:
        return None
        
    # Query mistakes for this session
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT sentence_attempted, user_answer, correct_answer, hint_given, timestamp
        FROM mistake_logs
        WHERE session_id = ?
        ORDER BY timestamp ASC
    """, (session_id,))
    mistakes = cursor.fetchall()
    conn.close()
    
    # Safe name for file
    safe_name = "".join([c for c in name if c.isalnum() or c in (' ', '_')]).strip().replace(' ', '_')
    filename = f"report_{safe_name}_session_{session_id}.csv"
    filepath = os.path.join(os.getcwd(), filename)
    
    with open(filepath, mode='w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        
        # Header / Title
        writer.writerow(["CHEF KOKO'S SENTENCE KITCHEN - PLAYER REPORT"])
        writer.writerow([])
        
        # Session info
        writer.writerow(["SESSION SUMMARY"])
        writer.writerow(["Player Name", session['player_name']])
        writer.writerow(["Date/Time", session['timestamp']])
        level_map = {1: "Easy (3 words)", 2: "Medium (4 words)", 3: "Hard (5 words)"}
        writer.writerow(["Selected Level", level_map.get(session['level'], str(session['level']))])
        writer.writerow(["Final Score", session['score']])
        writer.writerow(["Total Questions", session['total_questions']])
        writer.writerow(["Correct Answers", session['correct_answers']])
        writer.writerow(["Mistakes / Timeouts", session['mistakes']])
        writer.writerow(["Stars Earned", session['stars_earned']])
        writer.writerow([])
        
        # Mistakes Log
        writer.writerow(["MISTAKE AND HINT LOG"])
        writer.writerow(["Timestamp", "Target Sentence", "Child's Attempt", "Correct Answer", "Used Hint?"])
        
        if not mistakes:
            writer.writerow(["No mistakes logged. Perfect session!"])
        else:
            for m in mistakes:
                writer.writerow([
                    m['timestamp'],
                    m['sentence_attempted'],
                    m['user_answer'],
                    m['correct_answer'],
                    "Yes" if m['hint_given'] == 1 else "No"
                ])
                
    return filepath
