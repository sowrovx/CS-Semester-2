# levels_data.py
# All sentence content for Chef Koko's Sentence Kitchen
# Designed for early childhood literacy: Subject + Verb + Object and simple additions.

SENTENCES = {
    1: [  # Level 1: Easy (3 words)
        {"id": 101, "text": "I eat cake", "words": ["I", "eat", "cake"]},
        {"id": 102, "text": "She likes milk", "words": ["She", "likes", "milk"]},
        {"id": 103, "text": "Cats drink water", "words": ["Cats", "drink", "water"]},
        {"id": 104, "text": "Dogs chase balls", "words": ["Dogs", "chase", "balls"]},
        {"id": 105, "text": "He cooks rice", "words": ["He", "cooks", "rice"]},
        {"id": 106, "text": "They play games", "words": ["They", "play", "games"]},
        {"id": 107, "text": "Birds eat seeds", "words": ["Birds", "eat", "seeds"]},
        {"id": 108, "text": "Monkeys love bananas", "words": ["Monkeys", "love", "bananas"]},
        {"id": 109, "text": "We read books", "words": ["We", "read", "books"]},
        {"id": 110, "text": "Bears eat honey", "words": ["Bears", "eat", "honey"]},
        {"id": 111, "text": "Lions hunt deer", "words": ["Lions", "hunt", "deer"]},
        {"id": 112, "text": "Fish love water", "words": ["Fish", "love", "water"]}
    ],
    2: [  # Level 2: Medium (4 words)
        {"id": 201, "text": "The chef cooks soup", "words": ["The", "chef", "cooks", "soup"]},
        {"id": 202, "text": "I eat sweet apples", "words": ["I", "eat", "sweet", "apples"]},
        {"id": 203, "text": "She drinks cold juice", "words": ["She", "drinks", "cold", "juice"]},
        {"id": 204, "text": "We wash our hands", "words": ["We", "wash", "our", "hands"]},
        {"id": 205, "text": "They bake tasty cookies", "words": ["They", "bake", "tasty", "cookies"]},
        {"id": 206, "text": "He cut the bread", "words": ["He", "cut", "the", "bread"]},
        {"id": 207, "text": "My cat loves milk", "words": ["My", "cat", "loves", "milk"]},
        {"id": 208, "text": "Green frogs jump high", "words": ["Green", "frogs", "jump", "high"]},
        {"id": 209, "text": "Kids like sweet candy", "words": ["Kids", "like", "sweet", "candy"]},
        {"id": 210, "text": "Birds build small nests", "words": ["Birds", "build", "small", "nests"]},
        {"id": 211, "text": "Dogs bark at night", "words": ["Dogs", "bark", "at", "night"]},
        {"id": 212, "text": "They play soccer today", "words": ["They", "play", "soccer", "today"]}
    ],
    3: [  # Level 3: Hard (5 words)
        {"id": 301, "text": "The little chef bakes bread", "words": ["The", "little", "chef", "bakes", "bread"]},
        {"id": 302, "text": "She makes a delicious pizza", "words": ["She", "makes", "a", "delicious", "pizza"]},
        {"id": 303, "text": "We eat fresh fruit salad", "words": ["We", "eat", "fresh", "fruit", "salad"]},
        {"id": 304, "text": "He drinks a cold soda", "words": ["He", "drinks", "a", "cold", "soda"]},
        {"id": 305, "text": "They wash the dirty dishes", "words": ["They", "wash", "the", "dirty", "dishes"]},
        {"id": 306, "text": "My mother cooks tasty rice", "words": ["My", "mother", "cooks", "tasty", "rice"]},
        {"id": 307, "text": "Active kids play outside today", "words": ["Active", "kids", "play", "outside", "today"]},
        {"id": 308, "text": "Big brown bears eat honey", "words": ["Big", "brown", "bears", "eat", "honey"]},
        {"id": 309, "text": "Small birds sing sweet songs", "words": ["Small", "birds", "sing", "sweet", "songs"]},
        {"id": 310, "text": "I like my new kitchen", "words": ["I", "like", "my", "new", "kitchen"]},
        {"id": 311, "text": "The smart dog chases cats", "words": ["The", "smart", "dog", "chases", "cats"]},
        {"id": 312, "text": "We love to eat soup", "words": ["We", "love", "to", "eat", "soup"]}
    ]
}
