# ai.py
import random
import levels_data
import database

class AI:
    def __init__(self, player_id, initial_level):
        self.player_id = player_id
        self.level = initial_level  # 1 = Easy, 2 = Medium, 3 = Hard
        self.correct_streak = 0
        self.wrong_streak = 0
        
        # Load weak words from the database
        self.weak_words = database.get_mistake_patterns(player_id)
        
        # Keep track of sentences used in the current session
        self.used_sentence_ids = set()
        self.current_sentence = None
        self.hints_used = 0
        
    def reset_session_used(self):
        """Resets the used sentence tracker."""
        self.used_sentence_ids.clear()
        
    def next_sentence(self):
        """
        Picks the next sentence based on difficulty and adaptive weak-word logic.
        1. Get all sentences for current level that have not been used.
        2. Filter to find any containing words the child struggled with previously.
        3. 55% chance to pick from weak pool, otherwise random pool.
        4. If all sentences in the level are used, reset the used set and repeat.
        """
        pool = levels_data.SENTENCES.get(self.level, [])
        # Filter unused
        unused = [s for s in pool if s['id'] not in self.used_sentence_ids]
        
        if not unused:
            # All sentences used, reset tracker for this level
            self.used_sentence_ids.clear()
            unused = pool
            
        # Find weak sentences
        weak_pool = []
        for s in unused:
            # Check if any word in the sentence is a weak word (mistake count > 0)
            has_weak_word = any(word.lower() in [w.lower() for w in self.weak_words] for word in s['words'])
            if has_weak_word:
                weak_pool.append(s)
                
        # Decide which sentence to pick
        if weak_pool and random.random() < 0.55:
            selected = random.choice(weak_pool)
        else:
            selected = random.choice(unused)
            
        self.used_sentence_ids.add(selected['id'])
        self.current_sentence = selected
        self.hints_used = 0  # Reset hints for the new round
        
        # Generate shuffled words, ensuring it is not already in the correct order
        words = list(selected['words'])
        shuffled = words.copy()
        attempts = 0
        # Keep shuffling until they are scrambled (only if there are > 1 words)
        while len(shuffled) > 1 and shuffled == words and attempts < 100:
            random.shuffle(shuffled)
            attempts += 1
            
        return {
            "id": selected['id'],
            "correct_words": words,
            "shuffled_words": shuffled,
            "text": selected['text']
        }
        
    def check_answer(self, placed_words):
        """
        Checks if the placed words match the correct answer.
        Returns a tuple of (is_correct, incorrect_indices)
        """
        if not self.current_sentence:
            return False, []
            
        correct_words = self.current_sentence['words']
        is_correct = True
        incorrect_indices = []
        
        for i in range(len(correct_words)):
            if i < len(placed_words):
                if placed_words[i] != correct_words[i]:
                    is_correct = False
                    incorrect_indices.append(i)
            else:
                is_correct = False
                incorrect_indices.append(i)
                
        return is_correct, incorrect_indices
        
    def log_mistaken_words(self, placed_words):
        """
        Identify which words were placed in incorrect slots and record them as weak.
        For example: correct="I eat cake", user="eat I cake" -> 'I' and 'eat' are wrong.
        """
        if not self.current_sentence:
            return
            
        correct_words = self.current_sentence['words']
        for i, word in enumerate(placed_words):
            if i < len(correct_words):
                if word != correct_words[i]:
                    # Update local tracking
                    self.weak_words[word] = self.weak_words.get(word, 0) + 1

    def adjust_difficulty(self, round_was_perfect):
        """
        Adjusts level based on performance streaks.
        4 correct in a row -> level + 1 (max 3)
        3 wrong in a row -> level - 1 (min 1)
        Returns: (level_changed, old_level, new_level)
        """
        old_level = self.level
        level_changed = False
        
        if round_was_perfect:
            self.correct_streak += 1
            self.wrong_streak = 0
            if self.correct_streak >= 4:
                if self.level < 3:
                    self.level += 1
                    self.used_sentence_ids.clear()
                    level_changed = True
                self.correct_streak = 0
        else:
            self.wrong_streak += 1
            self.correct_streak = 0
            if self.wrong_streak >= 3:
                if self.level > 1:
                    self.level -= 1
                    self.used_sentence_ids.clear()
                    level_changed = True
                self.wrong_streak = 0
                
        return level_changed, old_level, self.level

    def get_stars_and_score(self, hints_used, time_taken, is_correct):
        """
        Calculates stars and points earned for the round.
        Scoring grid:
        - 3 stars: 0 hints, under 20 seconds. Points: E: 300, M: 600, H: 900
        - 2 stars: 1 or fewer hints. Points: E: 120, M: 240, H: 360
        - 1 star: 2 or 3 hints, but correct. Points: E: 30, M: 60, H: 90
        - 0 stars: wrong/timeout. Points: 0
        """
        if not is_correct:
            return 0, 0
            
        # Determine stars
        if hints_used == 0 and time_taken < 20:
            stars = 3
        elif hints_used <= 1:
            stars = 2
        else:
            stars = 1
            
        # Determine score
        score_matrix = {
            1: {3: 300, 2: 120, 1: 30},
            2: {3: 600, 2: 240, 1: 60},
            3: {3: 900, 2: 360, 1: 90}
        }
        
        points = score_matrix.get(self.level, {}).get(stars, 0)
        return stars, points

    def get_hint_info(self, placed_words):
        """
        Returns info for the next hint.
        Hint 1: Position hint. First incorrect word slot and what should go there.
        Hint 2: Move first word to slot 1.
        Hint 3: Snap all words into place.
        """
        if not self.current_sentence:
            return None
            
        self.hints_used = min(self.hints_used + 1, 3)
        correct_words = self.current_sentence['words']
        
        if self.hints_used == 1:
            # Find the first index where placed word is wrong
            wrong_idx = 0
            for i in range(len(correct_words)):
                if i >= len(placed_words) or placed_words[i] != correct_words[i]:
                    wrong_idx = i
                    break
            target_word = correct_words[wrong_idx]
            # Slot number is 1-indexed for the user
            return {
                "tier": 1,
                "text": f"Try putting the word {target_word} in position {wrong_idx + 1}",
                "target_word": target_word,
                "position": wrong_idx + 1
            }
        elif self.hints_used == 2:
            return {
                "tier": 2,
                "text": f"The first word is {correct_words[0]}. Start with that!",
                "first_word": correct_words[0]
            }
        else:
            return {
                "tier": 3,
                "text": self.current_sentence['text'],
                "sentence": self.current_sentence['text']
            }
