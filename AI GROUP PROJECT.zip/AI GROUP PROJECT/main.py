# main.py
import pygame
import sys
import time
import math
import random
import os

# Import modules
import database
import ai
import voice
import levels_data

# Screen States
S_MENU = 1
S_INSTR = 2
S_PLAY = 3
S_RESULTS = 4
S_LEADERBOARD = 5

class Tile:
    def __init__(self, word, home_pos, color):
        self.word = word
        self.home_pos = home_pos
        self.rect = pygame.Rect(home_pos[0], home_pos[1], 120, 58)
        self.color = color
        self.slot_index = None
        self.is_dragging = False
        self.highlighted = False

class Slot:
    def __init__(self, rect, index):
        self.rect = rect
        self.index = index
        self.tile = None

class Button:
    def __init__(self, x, y, w, h, text, bg_color, hover_color, text_color=(255, 255, 255), radius=14):
        self.rect = pygame.Rect(x, y, w, h)
        self.text = text
        self.bg_color = bg_color
        self.hover_color = hover_color
        self.text_color = text_color
        self.radius = radius
        self.is_hovered = False
        
    def update(self, mouse_pos):
        self.is_hovered = self.rect.collidepoint(mouse_pos)
        
    def draw(self, screen, font, active=True):
        # Draw drop shadow
        shadow_rect = self.rect.copy()
        shadow_rect.x += 2
        shadow_rect.y += 3
        pygame.draw.rect(screen, (0, 0, 0, 50), shadow_rect, border_radius=self.radius)
        
        color = self.hover_color if (self.is_hovered and active) else self.bg_color
        if not active:
            color = (180, 180, 180)
            
        pygame.draw.rect(screen, color, self.rect, border_radius=self.radius)
        border_color = tuple(max(0, c - 40) for c in color)
        pygame.draw.rect(screen, border_color, self.rect, width=3, border_radius=self.radius)
        
        txt_surf = font.render(self.text, True, self.text_color if active else (120, 120, 120))
        txt_rect = txt_surf.get_rect(center=self.rect.center)
        screen.blit(txt_surf, txt_rect)

class ConfettiParticle:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.vx = random.uniform(-5, 5)
        self.vy = random.uniform(-10, -3)
        self.color = random.choice([
            (255, 100, 160), # pink
            (255, 215, 0),   # gold/yellow
            (34, 139, 34),   # green
            (30, 77, 140),   # blue
            (106, 13, 189),  # purple
            (0, 128, 128)    # teal
        ])
        self.size = random.randint(6, 12)
        self.gravity = 0.25
        self.angle = random.uniform(0, 360)
        self.avel = random.uniform(-8, 8)

    def update(self):
        self.x += self.vx
        self.vy += self.gravity
        self.y += self.vy
        self.angle += self.avel

    def draw(self, screen):
        rad = math.radians(self.angle)
        cos_a = math.cos(rad) * self.size
        sin_a = math.sin(rad) * self.size
        points = [
            (self.x - cos_a, self.y - sin_a),
            (self.x + sin_a, self.y - cos_a),
            (self.x + cos_a, self.y + sin_a),
            (self.x - sin_a, self.y + cos_a)
        ]
        points = [(int(p[0]), int(p[1])) for p in points]
        pygame.draw.polygon(screen, self.color, points)

class Game:
    VOICE_EVENT_ID = pygame.USEREVENT + 1

    def __init__(self):
        pygame.init()
        pygame.mixer.init()
        # Load and play background music in a loop
        try:
            if os.path.exists("background_music.mpeg"):
                pygame.mixer.music.load("background_music.mpeg")
                pygame.mixer.music.set_volume(0.08) # Soft, unobtrusive volume
                pygame.mixer.music.play(-1, fade_ms=2000) # Loop indefinitely with 2s fade-in
        except Exception as e:
            print("Failed to load background music:", e)
            
        pygame.font.init()
        
        self.screen = pygame.display.set_mode((1024, 768))
        pygame.display.set_caption("Chef Koko's Sentence Kitchen")
        self.clock = pygame.time.Clock()
        
        # Init DB
        database.init_db()
        
        # Init Voice system
        voice.init_voice()
        
        # Load fonts
        self.font_title = self.load_kids_font(44)
        self.font_header = self.load_kids_font(32)
        self.font_medium = self.load_kids_font(22)
        self.font_small = self.load_kids_font(18)
        self.font_timer = self.load_kids_font(20)
        
        # Generate static background once
        self.bg_surface = pygame.Surface((1024, 768))
        self.draw_kitchen_background(self.bg_surface)
        
        # Load Chef Koko image
        try:
            if os.path.exists("koko_i.png"):
                self.chef_image = pygame.image.load("koko_i.png").convert_alpha()
                # Scale Koko to fit the game layout (210x290 pixels)
                self.chef_image = pygame.transform.smoothscale(self.chef_image, (210, 290))
                self.chef_image_loaded = True
            else:
                self.chef_image_loaded = False
        except Exception as e:
            print("Failed to load koko_i.png:", e)
            self.chef_image_loaded = False
        
        # Game states
        self.state = S_MENU
        self.anim_t = 0.0
        
        # 1. Main Menu States
        self.name_input = ""
        self.sel_level = None # 1=Easy, 2=Medium, 3=Hard
        self.menu_bubble_text = ""
        self.menu_bubble_timer = 0
        
        # Welcome voice cue triggered once
        voice.speak("Hi! What is your name? Please type your name to start!")
        
        # UI elements
        self.btn_easy = Button(312, 400, 120, 50, "EASY", (34, 139, 34), (50, 170, 50))
        self.btn_medium = Button(452, 400, 120, 50, "MEDIUM", (255, 140, 0), (255, 170, 40))
        self.btn_hard = Button(592, 400, 120, 50, "HARD", (204, 34, 0), (230, 60, 30))
        self.btn_start = Button(437, 510, 150, 55, "START", (34, 139, 34), (50, 170, 50))
        
        # 2. Instruction Screen States
        self.btn_lets_cook = Button(330, 570, 200, 55, "Let's Cook!", (34, 139, 34), (50, 170, 50))
        self.btn_repeat_instr = Button(560, 570, 240, 55, "Hear Again 🔊", (30, 77, 140), (50, 100, 180))
        
        # 3. Gameplay Screen States
        self.player_id = None
        self.pname = ""
        self.session_id = None
        self.ai = None
        self.round_num = 1
        self.score = 0
        self.total_stars = 0
        self.session_correct = 0
        self.session_mistakes = 0
        
        # Round-specific states
        self.round_state = "PLAYING" # PLAYING, CORRECT, WRONG, TIMEOUT
        self.round_time_left = 60.0
        self.round_start_time = 0.0
        self.correct_round_start = 0.0
        self.timeout_round_start = 0.0
        self.tiles = []
        self.slots = []
        self.board_rect = pygame.Rect(300, 200, 500, 100)
        self._drag_tile = None
        self._drag_offset_x = 0
        self._drag_offset_y = 0
        
        self.chef_expression = "HAPPY"
        self.chef_bubble_text = ""
        self.chef_bubble_timer = 0
        self.hint_text = ""
        self.hints_used_this_round = 0
        self.active_stars = 3
        self.confetti = []
        self.wrong_flash_timer = 0
        
        # Mic voice states
        self.is_listening = False
        self.mic_supported = voice.is_mic_available()
        
        # Gameplay Buttons
        self.btn_reset = Button(600, 680, 120, 50, "RESET", (0, 128, 128), (0, 160, 160))
        self.btn_hint = Button(735, 680, 120, 50, "HINT (3)", (255, 140, 0), (255, 170, 40))
        self.btn_check = Button(870, 680, 120, 50, "CHECK", (34, 139, 34), (50, 170, 50))
        self.btn_mic = Button(300, 680, 120, 50, "MIC", (30, 77, 140), (50, 100, 180))
        self.btn_end = Button(440, 680, 140, 50, "END GAME", (204, 34, 0), (230, 60, 30))
        self.rounds_completed = 6
        
        # 4. Results Screen States
        self.btn_play_again = Button(342, 580, 150, 55, "Play Again", (34, 139, 34), (50, 170, 50))
        self.btn_view_leaders = Button(532, 580, 150, 55, "Leaderboard", (106, 13, 189), (130, 30, 210))
        
        # 5. Leaderboard Screen States
        self.btn_export_csv = Button(342, 580, 160, 55, "Export Report", (0, 128, 128), (0, 160, 160))
        self.btn_home = Button(532, 580, 150, 55, "Home Menu", (30, 77, 140), (50, 100, 180))
        self.csv_export_message = ""
        self.csv_export_timer = 0.0

    def load_kids_font(self, size):
        font_names = ["arialrounded", "comicsansms", "trebuchetms", "helvetica", "arial"]
        for name in font_names:
            try:
                f = pygame.font.SysFont(name, size, bold=True)
                if f:
                    return f
            except Exception:
                continue
        return pygame.font.Font(None, size)

    def draw_gradient_y(self, surface, color1, color2, rect):
        y1, y2 = rect.top, rect.bottom
        h = rect.height
        for y in range(y1, y2):
            t = (y - y1) / h
            r = int(color1[0] * (1 - t) + color2[0] * t)
            g = int(color1[1] * (1 - t) + color2[1] * t)
            b = int(color1[2] * (1 - t) + color2[2] * t)
            pygame.draw.line(surface, (r, g, b), (rect.left, y), (rect.right, y))

    def draw_kitchen_background(self, surf):
        # Yellow wall with warm gradient
        self.draw_gradient_y(surf, (255, 235, 160), (255, 195, 80), pygame.Rect(0, 0, 1024, 530))
            
        # Brick tiles (middle band Y: 300 to 450)
        brick_h = 25
        brick_w = 60
        for by in range(300, 450, brick_h):
            row_offset = (by // brick_h) % 2 * (brick_w // 2)
            pygame.draw.line(surf, (210, 170, 30), (0, by), (1024, by), 2)
            for bx in range(-brick_w, 1024 + brick_w, brick_w):
                x = bx + row_offset
                pygame.draw.line(surf, (210, 170, 30), (x, by), (x, by + brick_h), 2)
                
        # Floor tiles (Y: 550 to 768)
        floor_y = 550
        self.draw_gradient_y(surf, (120, 60, 20), (80, 40, 10), pygame.Rect(0, floor_y, 1024, 768 - floor_y))
            
        # Floor grid lines (perspective lines)
        for x in range(0, 1024, 80):
            pygame.draw.line(surf, (150, 90, 40), (x, floor_y), (x - 100 + (x // 5), 768), 2)
        for y in range(floor_y, 768, 40):
            pygame.draw.line(surf, (150, 90, 40), (0, y), (1024, y), 2)
            
        # Counter top (Y: 520 to 550) - wooden counter top
        pygame.draw.rect(surf, (90, 45, 10), (0, 520, 1024, 30))
        pygame.draw.rect(surf, (140, 70, 20), (0, 520, 1024, 6)) # top highlight edge
        
        # Dark wood cabinets (Y: 0 to 110)
        pygame.draw.rect(surf, (70, 35, 15), (0, 0, 1024, 110))
        for i in range(8):
            cx = i * 128
            pygame.draw.rect(surf, (50, 25, 10), (cx + 8, 8, 112, 94), 2)
            pygame.draw.circle(surf, (218, 165, 32), (cx + 110, 55), 4) # Gold knobs
            
        # Window with garden (left side X: 40 to 240, Y: 140 to 330)
        pygame.draw.rect(surf, (135, 206, 235), (40, 140, 200, 190)) # Sky
        # Clouds
        pygame.draw.circle(surf, (255, 255, 255), (80, 170), 20)
        pygame.draw.circle(surf, (255, 255, 255), (105, 170), 25)
        pygame.draw.circle(surf, (255, 255, 255), (130, 170), 20)
        pygame.draw.circle(surf, (255, 255, 255), (180, 180), 15)
        # Green hills
        pygame.draw.ellipse(surf, (34, 139, 34), (0, 260, 250, 100))
        pygame.draw.ellipse(surf, (46, 139, 87), (100, 280, 200, 100))
        # Tree trunks and leaves
        pygame.draw.rect(surf, (101, 67, 33), (80, 230, 10, 50))
        pygame.draw.circle(surf, (0, 100, 0), (85, 210), 25)
        # Window frame
        pygame.draw.rect(surf, (120, 60, 20), (35, 135, 210, 200), 8) # Outer wood frame
        pygame.draw.line(surf, (120, 60, 20), (140, 135), (140, 335), 6) # vertical bar
        pygame.draw.line(surf, (120, 60, 20), (35, 235), (245, 235), 6) # horizontal bar
        
        # Hanging tools (left wall Y: 360 to 420)
        pygame.draw.line(surf, (100, 100, 100), (50, 370), (180, 370), 4) # metal rack
        # Spatula
        pygame.draw.line(surf, (150, 150, 150), (70, 370), (70, 410), 2)
        pygame.draw.rect(surf, (200, 200, 200), (66, 395, 10, 15), border_radius=2)
        # Spoon
        pygame.draw.line(surf, (150, 150, 150), (100, 370), (100, 410), 2)
        pygame.draw.circle(surf, (200, 200, 200), (100, 410), 6)
        # Oven mitt
        pygame.draw.line(surf, (150, 150, 150), (130, 370), (130, 380), 2)
        pygame.draw.ellipse(surf, (220, 60, 60), (120, 380, 20, 25)) # Red mitt
        pygame.draw.ellipse(surf, (220, 60, 60), (117, 387, 8, 12)) # Thumb
        # Whisk
        pygame.draw.line(surf, (150, 150, 150), (160, 370), (160, 410), 2)
        pygame.draw.ellipse(surf, (180, 180, 180), (157, 392, 8, 18), 1)
        
        # Hanging Lamp
        pygame.draw.line(surf, (50, 50, 50), (512, 110), (512, 180), 3) # cord
        pygame.draw.polygon(surf, (218, 165, 32), [(492, 180), (532, 180), (542, 205), (482, 205)]) # golden shade
        pygame.draw.circle(surf, (255, 253, 208), (512, 206), 8) # bulb
        
        # Range hood
        pygame.draw.polygon(surf, (80, 80, 80), [(800, 110), (940, 110), (960, 210), (780, 210)])
        pygame.draw.rect(surf, (60, 60, 60), (780, 210, 180, 10))
        
        # Oven/Stove
        pygame.draw.rect(surf, (100, 100, 100), (800, 500, 160, 180))
        pygame.draw.rect(surf, (50, 50, 50), (810, 530, 140, 130))
        pygame.draw.rect(surf, (255, 140, 0), (820, 550, 120, 80), 3) # window border
        
        # Pot on stove
        pygame.draw.rect(surf, (180, 50, 50), (820, 470, 50, 30), border_radius=4)
        pygame.draw.rect(surf, (100, 100, 100), (815, 466, 60, 5), border_radius=1)
        pygame.draw.circle(surf, (0, 0, 0), (845, 463), 3)
        pygame.draw.line(surf, (0, 0, 0), (870, 485), (885, 485), 3)
        
        # Fruit bowl
        pygame.draw.ellipse(surf, (200, 60, 60), (450, 502, 80, 20))
        pygame.draw.circle(surf, (34, 139, 34), (465, 500), 8) # green apple
        pygame.draw.circle(surf, (255, 165, 0), (480, 498), 9) # orange
        pygame.draw.circle(surf, (220, 20, 60), (495, 500), 8) # red apple
        pygame.draw.circle(surf, (255, 215, 0), (510, 501), 7) # lemon
        
        # Mugs and utensils
        pygame.draw.rect(surf, (30, 144, 255), (600, 495, 20, 25), border_radius=2)
        pygame.draw.ellipse(surf, (30, 144, 255), (615, 500, 10, 15), 2)
        pygame.draw.rect(surf, (245, 245, 220), (635, 490, 25, 30), border_radius=2)
        pygame.draw.line(surf, (150, 150, 150), (640, 490), (635, 475), 3)
        pygame.draw.circle(surf, (150, 150, 150), (635, 475), 4)
        pygame.draw.line(surf, (150, 150, 150), (648, 490), (648, 470), 2)
        pygame.draw.line(surf, (150, 150, 150), (655, 490), (660, 475), 3)
        pygame.draw.rect(surf, (150, 150, 150), (657, 470, 8, 8))
        
        # Salt & Pepper shakers
        pygame.draw.rect(surf, (240, 240, 240), (350, 505, 10, 15), border_radius=1)
        pygame.draw.rect(surf, (50, 50, 50), (350, 503, 10, 3))
        pygame.draw.rect(surf, (80, 80, 80), (365, 505, 10, 15), border_radius=1)
        pygame.draw.rect(surf, (150, 150, 150), (365, 503, 10, 3))

    def draw_chef_koko(self, screen, cx, cy, expression):
        bob_y = math.sin(self.anim_t) * 5
        cy_bob = cy + bob_y
        
        if self.chef_image_loaded:
            # Draw the static image of Koko (larger: 210x290 pixels) with bobbing physics applied
            screen.blit(self.chef_image, (cx - 105, int(cy_bob) - 145))
            
            # Only Koko's original closed mouth from the image is shown, no extra overlays are drawn on top
            
            # If Koko is celebrating, draw 5 gold stars around his head
            if expression == "CELEBRATE":
                star_positions = [
                    (cx - 65, cy_bob - 130),
                    (cx - 35, cy_bob - 155),
                    (cx, cy_bob - 170),
                    (cx + 35, cy_bob - 155),
                    (cx + 65, cy_bob - 130)
                ]
                for sx, sy in star_positions:
                    pygame.draw.polygon(screen, (255, 215, 0), [(sx, sy - 8), (sx + 5, sy), (sx, sy + 8), (sx - 5, sy)])
                    pygame.draw.polygon(screen, (255, 215, 0), [(sx - 8, sy), (sx, sy - 5), (sx + 8, sy), (sx, sy + 5)])
            return
        
        # 1. Shoes
        pygame.draw.ellipse(screen, (30, 30, 30), (cx - 30, cy_bob + 105, 24, 14))
        pygame.draw.ellipse(screen, (30, 30, 30), (cx + 6, cy_bob + 105, 24, 14))
        
        # 2. Legs
        pygame.draw.rect(screen, (30, 77, 140), (cx - 24, cy_bob + 60, 16, 50))
        pygame.draw.rect(screen, (30, 77, 140), (cx + 8, cy_bob + 60, 16, 50))
        
        # 3. Body / Coat
        pygame.draw.rect(screen, (245, 245, 245), (cx - 40, cy_bob - 20, 80, 85), border_radius=12)
        pygame.draw.line(screen, (220, 220, 220), (cx, cy_bob - 20), (cx, cy_bob + 60), 2)
        
        # Red Sash
        pygame.draw.rect(screen, (204, 34, 0), (cx - 41, cy_bob + 50, 82, 12), border_radius=3)
        
        # Buttons
        pygame.draw.circle(screen, (30, 77, 140), (cx - 15, cy_bob + 5), 4)
        pygame.draw.circle(screen, (30, 77, 140), (cx - 15, cy_bob + 25), 4)
        pygame.draw.circle(screen, (30, 77, 140), (cx + 15, cy_bob + 5), 4)
        pygame.draw.circle(screen, (30, 77, 140), (cx + 15, cy_bob + 25), 4)
        
        # 4. Arms
        if expression == "HAPPY":
            pygame.draw.ellipse(screen, (245, 245, 245), (cx - 58, cy_bob, 22, 35))
            pygame.draw.circle(screen, (255, 220, 177), (cx - 50, cy_bob + 32), 6) # Left Hand
            
            pygame.draw.ellipse(screen, (245, 245, 245), (cx + 36, cy_bob + 5, 22, 35))
            pygame.draw.circle(screen, (255, 220, 177), (cx + 46, cy_bob + 35), 6) # Right Hand
            pygame.draw.line(screen, (139, 69, 19), (cx + 46, cy_bob + 35), (cx + 56, cy_bob + 15), 3) # Spatula handle
            pygame.draw.rect(screen, (180, 180, 180), (cx + 52, cy_bob + 5, 12, 14), border_radius=1) # Spatula blade
            
        elif expression == "THINKING":
            pygame.draw.ellipse(screen, (245, 245, 245), (cx - 55, cy_bob + 10, 20, 40))
            pygame.draw.circle(screen, (255, 220, 177), (cx - 45, cy_bob + 45), 6)
            
            # Right hand touching chin
            pygame.draw.polygon(screen, (245, 245, 245), [(cx + 35, cy_bob + 10), (cx + 55, cy_bob + 20), (cx + 35, cy_bob - 15), (cx + 25, cy_bob - 10)])
            pygame.draw.circle(screen, (255, 220, 177), (cx + 28, cy_bob - 18), 7)
            
        elif expression == "CELEBRATE":
            # Left arm up
            pygame.draw.polygon(screen, (245, 245, 245), [(cx - 35, cy_bob - 10), (cx - 60, cy_bob - 40), (cx - 50, cy_bob - 48), (cx - 28, cy_bob - 15)])
            pygame.draw.circle(screen, (255, 220, 177), (cx - 56, cy_bob - 46), 7)
            # Right arm up
            pygame.draw.polygon(screen, (245, 245, 245), [(cx + 35, cy_bob - 10), (cx + 60, cy_bob - 40), (cx + 50, cy_bob - 48), (cx + 28, cy_bob - 15)])
            pygame.draw.circle(screen, (255, 220, 177), (cx + 56, cy_bob - 46), 7)
            
            # Floating stars
            star_positions = [
                (cx - 65, cy_bob - 95),
                (cx - 35, cy_bob - 120),
                (cx, cy_bob - 135),
                (cx + 35, cy_bob - 120),
                (cx + 65, cy_bob - 95)
            ]
            for sx, sy in star_positions:
                pygame.draw.polygon(screen, (255, 215, 0), [(sx, sy - 8), (sx + 5, sy), (sx, sy + 8), (sx - 5, sy)])
                pygame.draw.polygon(screen, (255, 215, 0), [(sx - 8, sy), (sx, sy - 5), (sx + 8, sy), (sx, sy + 5)])

        # 5. Head
        pygame.draw.ellipse(screen, (255, 220, 177), (cx - 42, cy_bob - 65, 84, 60))
        
        # 6. Hair
        pygame.draw.circle(screen, (30, 30, 30), (cx - 38, cy_bob - 58), 12)
        pygame.draw.circle(screen, (30, 30, 30), (cx + 38, cy_bob - 58), 12)
        
        # 7. Cheeks
        pygame.draw.circle(screen, (255, 170, 170), (cx - 26, cy_bob - 28), 9)
        pygame.draw.circle(screen, (255, 170, 170), (cx + 26, cy_bob - 28), 9)
        
        # 8. Nose
        pygame.draw.ellipse(screen, (244, 194, 149), (cx - 7, cy_bob - 38, 14, 10))
        
        # 9. Eyes
        if expression in ["HAPPY", "THINKING"]:
            # Left eye
            pygame.draw.circle(screen, (255, 255, 255), (cx - 16, cy_bob - 46), 8)
            pygame.draw.circle(screen, (30, 77, 140), (cx - 16, cy_bob - 46), 4) # Iris
            pygame.draw.circle(screen, (0, 0, 0), (cx - 16, cy_bob - 46), 2) # Pupil
            pygame.draw.circle(screen, (255, 255, 255), (cx - 14, cy_bob - 48), 1.5)
            # Right eye
            pygame.draw.circle(screen, (255, 255, 255), (cx + 16, cy_bob - 46), 8)
            pygame.draw.circle(screen, (30, 77, 140), (cx + 16, cy_bob - 46), 4)
            pygame.draw.circle(screen, (0, 0, 0), (cx + 16, cy_bob - 46), 2)
            pygame.draw.circle(screen, (255, 255, 255), (cx + 18, cy_bob - 48), 1.5)
            
            # Eyebrows
            if expression == "HAPPY":
                pygame.draw.arc(screen, (30, 30, 30), (cx - 24, cy_bob - 58, 16, 8), 0.2, 3.0, 2)
                pygame.draw.arc(screen, (30, 30, 30), (cx + 8, cy_bob - 58, 16, 8), 0.2, 3.0, 2)
            else: # THINKING
                pygame.draw.line(screen, (30, 30, 30), (cx - 24, cy_bob - 52), (cx - 8, cy_bob - 52), 2)
                pygame.draw.arc(screen, (30, 30, 30), (cx + 8, cy_bob - 64, 16, 8), 0.2, 3.0, 2)
                
        elif expression == "CELEBRATE":
            pygame.draw.arc(screen, (30, 30, 30), (cx - 24, cy_bob - 50, 16, 10), 0.1, 3.0, 3)
            pygame.draw.arc(screen, (30, 30, 30), (cx + 8, cy_bob - 50, 16, 10), 0.1, 3.0, 3)
            # Eyebrows
            pygame.draw.arc(screen, (30, 30, 30), (cx - 24, cy_bob - 62, 16, 8), 0.2, 3.0, 2)
            pygame.draw.arc(screen, (30, 30, 30), (cx + 8, cy_bob - 62, 16, 8), 0.2, 3.0, 2)
            
        # 10. Mouth
        if expression == "HAPPY":
            center = (cx, cy_bob - 32)
            radius = 12
            points = [center]
            for step in range(11):
                angle = (step / 10.0) * math.pi
                px = center[0] + int(math.cos(angle) * radius)
                py = center[1] + int(math.sin(angle) * radius)
                points.append((px, py))
            pygame.draw.polygon(screen, (139, 0, 0), points)
            pygame.draw.line(screen, (255, 255, 255), (cx - 10, cy_bob - 31), (cx + 10, cy_bob - 31), 3)
        elif expression == "THINKING":
            pygame.draw.line(screen, (30, 30, 30), (cx - 10, cy_bob - 26), (cx + 10, cy_bob - 26), 2)
        elif expression == "CELEBRATE":
            center = (cx, cy_bob - 34)
            radius = 16
            points = [center]
            for step in range(11):
                angle = (step / 10.0) * math.pi
                px = center[0] + int(math.cos(angle) * radius)
                py = center[1] + int(math.sin(angle) * radius)
                points.append((px, py))
            pygame.draw.polygon(screen, (139, 0, 0), points)
            pygame.draw.line(screen, (255, 255, 255), (cx - 14, cy_bob - 33), (cx + 14, cy_bob - 33), 3)

        # 11. Hat
        pygame.draw.rect(screen, (255, 255, 255), (cx - 32, cy_bob - 78, 64, 16), border_radius=2)
        pygame.draw.rect(screen, (204, 34, 0), (cx - 32, cy_bob - 72, 64, 3))
        # Puffs
        pygame.draw.circle(screen, (255, 255, 255), (cx, cy_bob - 95), 24)
        pygame.draw.circle(screen, (255, 255, 255), (cx - 18, cy_bob - 88), 18)
        pygame.draw.circle(screen, (255, 255, 255), (cx + 18, cy_bob - 88), 18)

    def draw_speech_bubble(self, screen, text, font, bx, by, bw, bh, anchor_x, anchor_y):
        # Draw drop shadow
        shadow_rect = pygame.Rect(bx + 2, by + 3, bw, bh)
        pygame.draw.rect(screen, (0, 0, 0, 40), shadow_rect, border_radius=15)
        
        # Draw bubble
        bubble_rect = pygame.Rect(bx, by, bw, bh)
        pygame.draw.rect(screen, (255, 255, 255), bubble_rect, border_radius=15)
        pygame.draw.rect(screen, (120, 60, 20), bubble_rect, width=3, border_radius=15)
        
        # Draw pointer triangle
        if anchor_x < bx:
            p1 = (bx, by + bh // 2 - 10)
            p2 = (bx, by + bh // 2 + 10)
            p3 = (anchor_x, anchor_y)
        else:
            p1 = (bx + bw, by + bh // 2 - 10)
            p2 = (bx + bw, by + bh // 2 + 10)
            p3 = (anchor_x, anchor_y)
            
        pygame.draw.polygon(screen, (0, 0, 0, 40), [(p1[0]+2, p1[1]+3), (p2[0]+2, p2[1]+3), (p3[0]+2, p3[1]+3)])
        pygame.draw.polygon(screen, (255, 255, 255), [p1, p2, p3])
        pygame.draw.line(screen, (120, 60, 20), p1, p3, 3)
        pygame.draw.line(screen, (120, 60, 20), p2, p3, 3)
        
        # Wrap and center text
        words = text.split(' ')
        lines = []
        curr_line = ""
        for word in words:
            test_line = curr_line + (" " if curr_line else "") + word
            if font.size(test_line)[0] < bw - 24:
                curr_line = test_line
            else:
                lines.append(curr_line)
                curr_line = word
        if curr_line:
            lines.append(curr_line)
            
        line_h = font.get_linesize()
        total_text_h = len(lines) * line_h
        start_y = by + (bh - total_text_h) // 2
        for i, line in enumerate(lines):
            surf = font.render(line, True, (120, 60, 20))
            rect = surf.get_rect(center=(bx + bw // 2, start_y + i * line_h + line_h // 2))
            screen.blit(surf, rect)

    def draw_star(self, screen, cx, cy, r, color):
        points = []
        for i in range(10):
            angle = i * math.pi / 5 - math.pi / 2
            radius = r if i % 2 == 0 else r * 0.4
            x = cx + math.cos(angle) * radius
            y = cy + math.sin(angle) * radius
            points.append((x, y))
        pygame.draw.polygon(screen, color, points)
        pygame.draw.polygon(screen, (max(0, color[0]-40), max(0, color[1]-40), max(0, color[2]-40)), points, 2)

    def draw_recipe_board(self, screen, board_rect):
        by1, by2 = board_rect.top, board_rect.bottom
        bh = board_rect.height
        # Wooden board Y gradient
        for y in range(by1, by2):
            t = (y - by1) / bh
            r = int(120 * (1 - t) + 80 * t)
            g = int(60 * (1 - t) + 40 * t)
            b = int(20 * (1 - t) + 10 * t)
            pygame.draw.line(screen, (r, g, b), (board_rect.left, y), (board_rect.right, y))
            
        # Wood grain lines
        for gy in range(by1 + 12, by2 - 12, 16):
            pygame.draw.line(screen, (70, 35, 10), (board_rect.left + 10, gy), (board_rect.right - 10, gy + int(math.sin(gy)*2)), 2)
            
        pygame.draw.rect(screen, (50, 25, 10), board_rect, width=4, border_radius=8)

    def draw_tile(self, screen, tile, font):
        if tile.slot_index is not None:
            bg_color = (200, 235, 200) # snapped green
            border_color = (34, 139, 34)
            text_color = (20, 80, 20)
        elif tile.highlighted:
            bg_color = (255, 215, 0) # hint gold
            border_color = (204, 153, 0)
            text_color = (90, 45, 10)
        else:
            bg_color = tile.color
            border_color = tuple(max(0, c - 40) for c in bg_color)
            if bg_color == (255, 215, 0): # Yellow
                text_color = (90, 45, 10)
            else:
                text_color = (255, 255, 255)
                
        rx, ry = tile.rect.x, tile.rect.y
        if tile.is_dragging:
            ry -= 8
            shadow_x, shadow_y = rx + 8, ry + 12
        else:
            shadow_x, shadow_y = rx + 4, ry + 6
            
        # Draw drop shadow
        shadow_rect = pygame.Rect(shadow_x, shadow_y, 120, 58)
        pygame.draw.rect(screen, (0, 0, 0, 70), shadow_rect, border_radius=14)
        
        # Draw tile body
        tile_rect_drawn = pygame.Rect(rx, ry, 120, 58)
        pygame.draw.rect(screen, bg_color, tile_rect_drawn, border_radius=14)
        
        # Shine glass band
        shine_surf = pygame.Surface((120, 18), pygame.SRCALPHA)
        shine_surf.fill((255, 255, 255, 80))
        screen.blit(shine_surf, (rx, ry))
        
        # Border
        pygame.draw.rect(screen, border_color, tile_rect_drawn, width=3, border_radius=14)
        
        # Text
        txt_surf = font.render(tile.word, True, text_color)
        txt_rect = txt_surf.get_rect(center=tile_rect_drawn.center)
        screen.blit(txt_surf, txt_rect)

    def _go_instr(self):
        # Create/Get Player
        player = database.get_or_create_player(self.name_input)
        self.player_id = player['id']
        self.pname = player['name']
        self.state = S_INSTR
        
        # Narration of all 5 steps
        voice.speak(
            f"Hello {self.pname}! Let me show you how to play! "
            "Step 1. Chef Koko reads a sentence. Listen carefully! "
            "Step 2. Drag word tiles into the correct order on the board. "
            "Step 3. Press check when you think you are right! "
            "Step 4. Use hint if you are stuck, Chef will help! "
            "Step 5. Get 3 stars for a fast perfect answer! "
            "Click Let's Cook to start!"
        )

    def _begin_round(self):
        self.round_state = "PLAYING"
        self.chef_expression = "HAPPY"
        self.chef_bubble_text = ""
        self.hint_text = ""
        self.hints_used_this_round = 0
        self.active_stars = 3
        self.confetti.clear()
        
        # Fetch next sentence
        self.current_sentence = self.ai.next_sentence()
        
        # Reset timer
        self.round_time_left = 60.0
        self.round_start_time = time.time()
        
        # Build slots centered
        N = len(self.current_sentence['correct_words'])
        total_slots_width = N * 120 + (N - 1) * 12
        board_w = total_slots_width + 40
        board_x = 300 + (700 - board_w) // 2
        self.board_rect = pygame.Rect(board_x, 200, board_w, 100)
        
        self.slots = []
        for i in range(N):
            sx = board_x + 20 + i * (120 + 12)
            sy = 220
            self.slots.append(Slot(pygame.Rect(sx, sy, 120, 58), i))
            
        # Build tiles in bank
        total_tiles_width = N * 120 + (N - 1) * 20
        bank_x = 300 + (700 - total_tiles_width) // 2
        
        # Cycle colors
        colors = [
            (204, 34, 0),    # Red
            (30, 77, 140),   # Blue
            (34, 139, 34),   # Green
            (255, 215, 0),   # Yellow
            (106, 13, 189),  # Purple
            (0, 128, 128),   # Teal
            (255, 100, 160)  # Pink
        ]
        
        self.tiles = []
        for i, word in enumerate(self.current_sentence['shuffled_words']):
            tx = bank_x + i * (120 + 20)
            ty = 420
            color = colors[i % len(colors)]
            self.tiles.append(Tile(word, (tx, ty), color))
            
        # Read sentence
        voice.speak(f"Listen! {self.current_sentence['text']}")

    def _check_answer(self):
        # Collect placed words
        placed_words = []
        for slot in self.slots:
            if slot.tile:
                placed_words.append(slot.tile.word)
            else:
                placed_words.append("")
                
        is_correct, incorrect_indices = self.ai.check_answer(placed_words)
        
        if is_correct:
            self.round_state = "CORRECT"
            self.chef_expression = "CELEBRATE"
            self.correct_round_start = time.time()
            self.session_correct += 1
            
            # Lock tiles
            for tile in self.tiles:
                tile.highlighted = False
                
            # Score details
            time_taken = 60.0 - self.round_time_left
            stars, points = self.ai.get_stars_and_score(self.hints_used_this_round, time_taken, is_correct=True)
            self.score += points
            self.total_stars += stars
            self.active_stars = stars
            
            # Confetti
            self.confetti = [ConfettiParticle(random.randint(300, 950), random.randint(100, 350)) for _ in range(120)]
            
            # Praise TTS
            if stars == 3:
                praise_options = [
                    f"Perfect cooking, {self.pname}! You earned 3 stars!",
                    f"Yum yum, {self.pname}! That is a perfect sentence! 3 stars!",
                    f"Wow, {self.pname}! Super fast and perfect! 3 stars!"
                ]
                msg = random.choice(praise_options)
                voice.speak(msg)
                self.chef_bubble_text = f"Perfect, {self.pname}! 3 stars!"
            elif stars == 2:
                praise_options = [
                    f"Well done, {self.pname}! You did it!",
                    f"Great job, {self.pname}! That is correct!",
                    f"You got it, {self.pname}! Excellent work!"
                ]
                msg = random.choice(praise_options)
                voice.speak(msg)
                self.chef_bubble_text = f"Well done, {self.pname}!"
            else:
                praise_options = [
                    f"You got it, {self.pname}! Keep it up!",
                    f"Nice work, {self.pname}! Correct!",
                    f"Good job, {self.pname}! It's correct!"
                ]
                msg = random.choice(praise_options)
                voice.speak(msg)
                self.chef_bubble_text = f"You got it, {self.pname}!"
                
            self.chef_bubble_timer = time.time()
            
        else:
            # Wrong answer
            self.wrong_flash_timer = 15 # 15 frames red flash
            self.chef_expression = "THINKING"
            self.session_mistakes += 1
            
            # Log to DB
            user_ans_str = " ".join([w if w else "[empty]" for w in placed_words])
            hint_used = 1 if self.hints_used_this_round > 0 else 0
            database.log_mistake(self.session_id, self.current_sentence['text'], user_ans_str, self.current_sentence['text'], hint_used)
            
            # Local adaptive AI tracking
            self.ai.log_mistaken_words(placed_words)
            
            # Encouraging wrong answer feedback (courageous response)
            wrong_options = [
                f"Almost {self.pname}! You can do it! Try again!",
                f"Good try {self.pname}! Keep practicing, try once more!",
                f"Not quite {self.pname}! Try shifting the words to other spots!",
                f"Almost there {self.pname}! Don't give up, try again!"
            ]
            msg = random.choice(wrong_options)
            voice.speak(msg)
            self.chef_bubble_text = msg
            self.chef_bubble_timer = time.time()
            
            # Reset wrong streak on AI logic inside register_round_result?
            # Actually, adjust_difficulty is called at the end of the round.
            # During the round, if they submit a wrong answer, they can keep trying.
            # But the correct streak resets!
            self.ai.correct_streak = 0

    def _trigger_timeout(self):
        self.round_state = "TIMEOUT"
        self.timeout_round_start = time.time()
        self.chef_expression = "THINKING"
        self.session_mistakes += 1
        
        # Log to DB
        placed_words = [slot.tile.word if slot.tile else "[empty]" for slot in self.slots]
        user_ans_str = " ".join(placed_words)
        hint_used = 1 if self.hints_used_this_round > 0 else 0
        database.log_mistake(self.session_id, self.current_sentence['text'], user_ans_str, self.current_sentence['text'], hint_used)
        
        voice.speak(f"Time is up {self.pname}! Keep going!")
        self.chef_bubble_text = f"Time is up {self.pname}! Keep going!"
        self.chef_bubble_timer = time.time()

    # Event handlers
    def _e_menu(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse_pos = pygame.mouse.get_pos()
            
            # Level Buttons
            self.btn_easy.update(mouse_pos)
            self.btn_medium.update(mouse_pos)
            self.btn_hard.update(mouse_pos)
            self.btn_start.update(mouse_pos)
            
            if self.btn_easy.is_hovered:
                self.sel_level = 1
                voice.speak("Level Easy selected!")
            elif self.btn_medium.is_hovered:
                self.sel_level = 2
                voice.speak("Level Medium selected!")
            elif self.btn_hard.is_hovered:
                self.sel_level = 3
                voice.speak("Level Hard selected!")
            elif self.btn_start.is_hovered:
                if self.name_input.strip() and self.sel_level:
                    self._go_instr()
                elif not self.name_input.strip():
                    self.menu_bubble_text = "Please type your name first!"
                    self.menu_bubble_timer = time.time()
                    voice.speak("Please type your name first!")
                else:
                    self.menu_bubble_text = "Please select a level!"
                    self.menu_bubble_timer = time.time()
                    voice.speak("Please select a level!")
                    
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_BACKSPACE:
                self.name_input = self.name_input[:-1]
            elif event.key == pygame.K_RETURN:
                if self.name_input.strip() and self.sel_level:
                    self._go_instr()
                elif not self.name_input.strip():
                    self.menu_bubble_text = "Please type your name first!"
                    self.menu_bubble_timer = time.time()
                    voice.speak("Please type your name first!")
                else:
                    self.menu_bubble_text = "Please select a level!"
                    self.menu_bubble_timer = time.time()
                    voice.speak("Please select a level!")
            else:
                if len(self.name_input) < 12:
                    char = event.unicode
                    # Accept alphabet/numbers/spaces
                    if char.isalnum() or char == ' ':
                        self.name_input += char

    def _e_instr(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse_pos = pygame.mouse.get_pos()
            self.btn_lets_cook.update(mouse_pos)
            self.btn_repeat_instr.update(mouse_pos)
            
            if self.btn_lets_cook.is_hovered:
                # Stop active voice instructions
                voice.stop()
                
                # Setup session
                self.session_id = database.create_session(self.player_id, self.sel_level)
                self.ai = ai.AI(self.player_id, self.sel_level)
                
                # Reset Stats
                self.round_num = 1
                self.score = 0
                self.total_stars = 0
                self.session_correct = 0
                self.session_mistakes = 0
                
                # Start
                self.state = S_PLAY
                self._begin_round()
            elif self.btn_repeat_instr.is_hovered or (45 <= mouse_pos[0] <= 255 and 335 <= mouse_pos[1] <= 625):
                voice.speak(
                    f"Hello {self.pname}! Let me show you how to play! "
                    "Step 1. Chef Koko reads a sentence. Listen carefully! "
                    "Step 2. Drag word tiles into the correct order on the board. "
                    "Step 3. Press check when you think you are right! "
                    "Step 4. Use hint if you are stuck, Chef will help! "
                    "Step 5. Get 3 stars for a fast perfect answer! "
                    "Click Let's Cook to start!"
                )
            else:
                # Check if any step row was clicked
                start_y = 175
                step_texts = [
                    "Step 1. Chef Koko reads a sentence. Listen carefully!",
                    "Step 2. Drag word tiles into the correct order on the board.",
                    "Step 3. Press check when you think you are right!",
                    "Step 4. Use hint if you are stuck, Chef will help!",
                    "Step 5. Get 3 stars for a fast perfect answer!"
                ]
                for text in step_texts:
                    box_rect = pygame.Rect(300, start_y, 570, 50)
                    if box_rect.collidepoint(mouse_pos):
                        voice.speak(text)
                        break
                    start_y += 75

    def _e_play(self, event):
        # Receive voice recognition event
        if event.type == self.VOICE_EVENT_ID:
            self.is_listening = False
            voice.set_mic_active(False)
            if event.dict.get("success", False):
                spoken = event.dict.get("text", "")
                target = self.current_sentence['text']
                matched, ratio = voice.check_word_match(spoken, target)
                
                if matched:
                    # Snap all tiles and trigger correct flow
                    correct_words = self.current_sentence['correct_words']
                    for i, w in enumerate(correct_words):
                        # Find tile
                        tile = next(t for t in self.tiles if t.word == w)
                        if tile.slot_index is not None:
                            self.slots[tile.slot_index].tile = None
                        tile.slot_index = i
                        self.slots[i].tile = tile
                        tile.rect.topleft = self.slots[i].rect.topleft
                    self._check_answer()
                else:
                    # Wrong voice match
                    self.wrong_flash_timer = 15
                    self.chef_expression = "THINKING"
                    self.session_mistakes += 1
                    
                    # Log mistake
                    database.log_mistake(self.session_id, target, f"[Spoke: {spoken}]", target, 0)
                    
                    voice.speak(f"I heard {spoken} but not quite right!")
                    self.chef_bubble_text = f"I heard: '{spoken}' but not quite right!"
                    self.chef_bubble_timer = time.time()
                    self.ai.correct_streak = 0
            else:
                # Voice failed
                err = event.dict.get("text", "")
                voice.speak("Chef Koko didn't hear that. Try dragging tiles!")
                self.chef_bubble_text = "Chef Koko didn't hear you. Try dragging tiles!"
                self.chef_bubble_timer = time.time()
            return

        if self.round_state != "PLAYING" or self.is_listening:
            # Disable actions when not actively playing or listening
            return

        mouse_pos = pygame.mouse.get_pos()

        if event.type == pygame.MOUSEBUTTONDOWN:
            # Check tiles
            for tile in reversed(self.tiles):
                if tile.rect.collidepoint(mouse_pos):
                    # Pick up
                    tile.is_dragging = True
                    self._drag_tile = tile
                    self._drag_offset_x = tile.rect.x - mouse_pos[0]
                    self._drag_offset_y = tile.rect.y - mouse_pos[1]
                    
                    # If it was in a slot, empty that slot
                    if tile.slot_index is not None:
                        self.slots[tile.slot_index].tile = None
                        tile.slot_index = None
                    break
            
            # Check Buttons
            self.btn_reset.update(mouse_pos)
            self.btn_hint.update(mouse_pos)
            self.btn_check.update(mouse_pos)
            self.btn_mic.update(mouse_pos)
            self.btn_end.update(mouse_pos)
            
            if self.btn_reset.is_hovered:
                # Reset tiles to bank
                for tile in self.tiles:
                    tile.rect.topleft = tile.home_pos
                    tile.slot_index = None
                    tile.highlighted = False
                for slot in self.slots:
                    slot.tile = None
                    
                voice.speak(f"Let me read it again! {self.current_sentence['text']}")
                self.chef_expression = "HAPPY"
                self.chef_bubble_text = f"Listen! {self.current_sentence['text']}"
                self.chef_bubble_timer = time.time()
                
            elif self.btn_hint.is_hovered and self.hints_used_this_round < 3:
                # Get hint from AI
                placed_words = [slot.tile.word if slot.tile else "" for slot in self.slots]
                hint = self.ai.get_hint_info(placed_words)
                self.hints_used_this_round += 1
                
                if hint:
                    self.chef_expression = "THINKING"
                    self.chef_bubble_text = hint['text']
                    self.chef_bubble_timer = time.time()
                    self.hint_text = hint['text']
                    voice.speak(hint['text'])
                    
                    # Apply hint action
                    if hint['tier'] == 1:
                        # Highlight tile in bank
                        target_word = hint['target_word']
                        for tile in self.tiles:
                            if tile.word == target_word:
                                tile.highlighted = True
                            else:
                                tile.highlighted = False
                                
                    elif hint['tier'] == 2:
                        # Snap first word to slot 0
                        first_word = hint['first_word']
                        # Find tile
                        tile = next(t for t in self.tiles if t.word == first_word)
                        # Clear slot 0 if occupied
                        if self.slots[0].tile:
                            occ_tile = self.slots[0].tile
                            occ_tile.rect.topleft = occ_tile.home_pos
                            occ_tile.slot_index = None
                        # Clear old slot if tile was placed elsewhere
                        if tile.slot_index is not None:
                            self.slots[tile.slot_index].tile = None
                        # Snap to slot 0
                        tile.slot_index = 0
                        self.slots[0].tile = tile
                        tile.rect.topleft = self.slots[0].rect.topleft
                        tile.highlighted = False
                        
                    elif hint['tier'] == 3:
                        # Snap all
                        correct_words = self.current_sentence['correct_words']
                        for i, w in enumerate(correct_words):
                            tile = next(t for t in self.tiles if t.word == w)
                            if tile.slot_index is not None:
                                self.slots[tile.slot_index].tile = None
                            tile.slot_index = i
                            self.slots[i].tile = tile
                            tile.rect.topleft = self.slots[i].rect.topleft
                            tile.highlighted = False
                            
            elif self.btn_check.is_hovered:
                # All slots filled check
                all_filled = all(slot.tile is not None for slot in self.slots)
                if all_filled:
                    self._check_answer()
                    
            elif self.btn_mic.is_hovered and self.mic_supported:
                # Start Speech Recognition
                self.is_listening = True
                self.chef_expression = "HAPPY"
                self.chef_bubble_text = "Say the sentence!"
                self.chef_bubble_timer = time.time()
                voice.set_mic_active(True)
                voice.speak("Say the sentence!")
                voice.start_listening(self.VOICE_EVENT_ID)
                
            elif self.btn_end.is_hovered:
                # End session early
                self.rounds_completed = self.round_num - 1
                database.update_session(self.session_id, self.score, self.rounds_completed, self.session_correct, self.session_mistakes, self.total_stars)
                database.update_progress(self.player_id, self.ai.level, self.score)
                self.state = S_RESULTS
                voice.speak(f"Game ended early! You scored {self.score} points!")
                self.chef_expression = "HAPPY"

        elif event.type == pygame.MOUSEBUTTONUP:
            if self._drag_tile:
                snapped = False
                # Check empty slots
                for slot in self.slots:
                    if slot.tile is None:
                        scx, scy = slot.rect.center
                        dist = math.hypot(mouse_pos[0] - scx, mouse_pos[1] - scy)
                        if dist < 90:
                            # Snap
                            self._drag_tile.rect.topleft = slot.rect.topleft
                            self._drag_tile.slot_index = slot.index
                            slot.tile = self._drag_tile
                            snapped = True
                            break
                if not snapped:
                    # Return to bank
                    self._drag_tile.rect.topleft = self._drag_tile.home_pos
                    self._drag_tile.slot_index = None
                    
                self._drag_tile.is_dragging = False
                self._drag_tile = None

        elif event.type == pygame.MOUSEMOTION:
            if self._drag_tile:
                self._drag_tile.rect.x = mouse_pos[0] + self._drag_offset_x
                self._drag_tile.rect.y = mouse_pos[1] + self._drag_offset_y

    def _e_results(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse_pos = pygame.mouse.get_pos()
            self.btn_play_again.update(mouse_pos)
            self.btn_view_leaders.update(mouse_pos)
            
            if self.btn_play_again.is_hovered:
                self.state = S_MENU
                voice.speak("Back to the menu!")
            elif self.btn_view_leaders.is_hovered:
                self.state = S_LEADERBOARD
                self.csv_export_message = ""

    def _e_leaderboard(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse_pos = pygame.mouse.get_pos()
            self.btn_export_csv.update(mouse_pos)
            self.btn_home.update(mouse_pos)
            
            if self.btn_export_csv.is_hovered:
                path = database.export_csv(self.session_id, self.pname)
                if path:
                    fn = os.path.basename(path)
                    if len(fn) > 30:
                        fn = fn[:15] + "..." + fn[-12:]
                    self.csv_export_message = f"Report saved as: {fn}"
                else:
                    self.csv_export_message = "Failed to export report."
                self.csv_export_timer = time.time()
                
            elif self.btn_home.is_hovered:
                self.state = S_MENU
                voice.speak("Back to the menu!")

    # Update state
    def update(self):
        self.anim_t += 0.04
        
        if self.state == S_PLAY:
            if self.round_state == "PLAYING" and not self.is_listening:
                self.round_time_left = 60.0 - (time.time() - self.round_start_time)
                if self.round_time_left <= 0:
                    self.round_time_left = 0.0
                    self._trigger_timeout()
                    
            elif self.round_state == "CORRECT":
                for p in self.confetti:
                    p.update()
                # 3.5 seconds delay before next round
                if time.time() - self.correct_round_start >= 3.5:
                    # adjust level and proceed
                    level_changed, old, new = self.ai.adjust_difficulty(round_was_perfect=(self.hints_used_this_round == 0))
                    if level_changed:
                        self.sel_level = new
                        level_names = {1: "Easy", 2: "Medium", 3: "Hard"}
                        voice.speak(f"Level {level_names[new]} selected!")
                        
                    self.round_num += 1
                    if self.round_num > 6:
                        # End Session
                        self.rounds_completed = 6
                        database.update_session(self.session_id, self.score, 6, self.session_correct, self.session_mistakes, self.total_stars)
                        database.update_progress(self.player_id, self.ai.level, self.score)
                        self.state = S_RESULTS
                        voice.speak(f"Amazing {self.pname}! You scored {self.score} points!")
                    else:
                        self._begin_round()
                        
            elif self.round_state == "TIMEOUT":
                if time.time() - self.timeout_round_start >= 3.5:
                    self.ai.adjust_difficulty(round_was_perfect=False)
                    self.round_num += 1
                    if self.round_num > 6:
                        self.rounds_completed = 6
                        database.update_session(self.session_id, self.score, 6, self.session_correct, self.session_mistakes, self.total_stars)
                        database.update_progress(self.player_id, self.ai.level, self.score)
                        self.state = S_RESULTS
                        voice.speak(f"Amazing {self.pname}! You scored {self.score} points!")
                    else:
                        self._begin_round()
                        
            if self.wrong_flash_timer > 0:
                self.wrong_flash_timer -= 1
                
        # Hover states update
        mouse_pos = pygame.mouse.get_pos()
        if self.state == S_MENU:
            self.btn_easy.update(mouse_pos)
            self.btn_medium.update(mouse_pos)
            self.btn_hard.update(mouse_pos)
            self.btn_start.update(mouse_pos)
        elif self.state == S_INSTR:
            self.btn_lets_cook.update(mouse_pos)
            self.btn_repeat_instr.update(mouse_pos)
        elif self.state == S_PLAY:
            self.btn_reset.update(mouse_pos)
            self.btn_hint.update(mouse_pos)
            self.btn_check.update(mouse_pos)
            self.btn_mic.update(mouse_pos)
            self.btn_end.update(mouse_pos)
        elif self.state == S_RESULTS:
            self.btn_play_again.update(mouse_pos)
            self.btn_view_leaders.update(mouse_pos)
        elif self.state == S_LEADERBOARD:
            self.btn_export_csv.update(mouse_pos)
            self.btn_home.update(mouse_pos)

    # Drawing functions
    def draw(self):
        # Always start by blitting the static background
        self.screen.blit(self.bg_surface, (0, 0))
        
        if self.state == S_MENU:
            self._d_menu()
        elif self.state == S_INSTR:
            self._d_instr()
        elif self.state == S_PLAY:
            self._d_play()
        elif self.state == S_RESULTS:
            self._d_results()
        elif self.state == S_LEADERBOARD:
            self._d_leaderboard()
            
        pygame.display.flip()

    def _d_menu(self):
        # Chef bobbing on left
        self.draw_chef_koko(self.screen, 180, 480, "HAPPY")
        
        # Title Box
        t_rect = pygame.Rect(100, 30, 824, 80)
        pygame.draw.rect(self.screen, (255, 140, 0), t_rect, border_radius=15)
        pygame.draw.rect(self.screen, (120, 60, 20), t_rect, width=4, border_radius=15)
        
        title_surf = self.font_title.render("Chef Koko's Sentence Kitchen!", True, (255, 255, 255))
        title_rect = title_surf.get_rect(center=t_rect.center)
        self.screen.blit(title_surf, title_rect)
        
        # Central Login Card
        card = pygame.Rect(280, 160, 464, 400)
        pygame.draw.rect(self.screen, (255, 248, 220), card, border_radius=15)
        pygame.draw.rect(self.screen, (120, 60, 20), card, width=4, border_radius=15)
        
        # Name Input Box
        lbl = self.font_header.render("What is your name?", True, (120, 60, 20))
        lbl_rect = lbl.get_rect(center=(512, 210))
        self.screen.blit(lbl, lbl_rect)
        
        in_box = pygame.Rect(312, 250, 400, 50)
        pygame.draw.rect(self.screen, (255, 255, 255), in_box, border_radius=10)
        # Glow border if focused
        pygame.draw.rect(self.screen, (255, 140, 0), in_box, width=3, border_radius=10)
        
        # Render typed name or placeholder
        if not self.name_input:
            name_surf = self.font_medium.render("Type your name here...", True, (180, 180, 180))
        else:
            name_surf = self.font_medium.render(self.name_input, True, (0, 0, 0))
            
        name_rect = name_surf.get_rect(midleft=(324, 275))
        self.screen.blit(name_surf, name_rect)
        
        # Blinking cursor
        if self.name_input and int(time.time() * 2) % 2 == 0:
            cursor_x = name_rect.right + 2
            pygame.draw.line(self.screen, (0, 0, 0), (cursor_x, 260), (cursor_x, 290), 2)
            
        # Level Selection Label
        lbl_lvl = self.font_header.render("Choose Difficulty:", True, (120, 60, 20))
        lbl_lvl_rect = lbl_lvl.get_rect(center=(512, 350))
        self.screen.blit(lbl_lvl, lbl_lvl_rect)
        
        # Level Buttons
        self.btn_easy.draw(self.screen, self.font_medium)
        self.btn_medium.draw(self.screen, self.font_medium)
        self.btn_hard.draw(self.screen, self.font_medium)
        
        # Selected Level Outline indicator
        if self.sel_level == 1:
            pygame.draw.rect(self.screen, (255, 215, 0), self.btn_easy.rect, width=4, border_radius=14)
        elif self.sel_level == 2:
            pygame.draw.rect(self.screen, (255, 215, 0), self.btn_medium.rect, width=4, border_radius=14)
        elif self.sel_level == 3:
            pygame.draw.rect(self.screen, (255, 215, 0), self.btn_hard.rect, width=4, border_radius=14)
            
        # START Button
        is_ready = bool(self.name_input.strip() and self.sel_level)
        self.btn_start.draw(self.screen, self.font_header, active=is_ready)
        
        # Chef Speech Bubble (for warnings)
        if self.menu_bubble_text and time.time() - self.menu_bubble_timer < 3.0:
            self.draw_speech_bubble(self.screen, self.menu_bubble_text, self.font_small, 220, 310, 210, 70, 180, 430)

    def _d_instr(self):
        # Chef on left
        self.draw_chef_koko(self.screen, 150, 480, "HAPPY")
        
        # Large Card
        card = pygame.Rect(260, 90, 650, 560)
        pygame.draw.rect(self.screen, (255, 248, 220), card, border_radius=15)
        pygame.draw.rect(self.screen, (120, 60, 20), card, width=4, border_radius=15)
        
        # Title
        t_surf = self.font_title.render("How To Play", True, (255, 140, 0))
        t_rect = t_surf.get_rect(center=(585, 130))
        self.screen.blit(t_surf, t_rect)
        
        # 5 steps
        steps = [
            ("1", "Chef Koko reads a sentence — listen carefully!", (30, 77, 140)), # Blue
            ("2", "Drag word tiles into the correct order on the board", (0, 128, 128)), # Teal
            ("3", "Press CHECK when you think you are right!", (34, 139, 34)), # Green
            ("4", "Use HINT if you are stuck — Chef will help!", (255, 140, 0)), # Orange
            ("5", "Get 3 stars for a fast perfect answer!", (255, 100, 160)) # Pink
        ]
        
        start_y = 175
        for num, text, color in steps:
            # Circle
            pygame.draw.circle(self.screen, color, (320, start_y + 25), 18)
            num_surf = self.font_medium.render(num, True, (255, 255, 255))
            num_rect = num_surf.get_rect(center=(320, start_y + 25))
            self.screen.blit(num_surf, num_rect)
            
            # Step box
            s_box = pygame.Rect(350, start_y + 5, 520, 42)
            pygame.draw.rect(self.screen, (255, 255, 255), s_box, border_radius=8)
            pygame.draw.rect(self.screen, (120, 60, 20), s_box, width=1, border_radius=8)
            
            # Text inside
            step_text = self.font_medium.render(text, True, (120, 60, 20))
            st_rect = step_text.get_rect(midleft=(362, start_y + 26))
            self.screen.blit(step_text, st_rect)
            
            start_y += 75
            
        # Let's Cook button
        self.btn_lets_cook.draw(self.screen, self.font_header)
        self.btn_repeat_instr.draw(self.screen, self.font_header)

    def _d_play(self):
        # 1. Top bar
        pygame.draw.rect(self.screen, (70, 35, 15), (0, 0, 1024, 70))
        
        # Round counter
        rc_surf = self.font_header.render(f"ROUND {self.round_num}/6", True, (255, 255, 255))
        self.screen.blit(rc_surf, (20, 18))
        
        # Level badge
        lvl_names = {1: "EASY", 2: "MEDIUM", 3: "HARD"}
        lvl_colors = {1: (34, 139, 34), 2: (255, 140, 0), 3: (204, 34, 0)}
        level_name = lvl_names.get(self.sel_level, "EASY")
        l_color = lvl_colors.get(self.sel_level, (34, 139, 34))
        
        badge_rect = pygame.Rect(210, 18, 120, 36)
        pygame.draw.rect(self.screen, l_color, badge_rect, border_radius=8)
        lvl_surf = self.font_medium.render(level_name, True, (255, 255, 255))
        lvl_rect = lvl_surf.get_rect(center=badge_rect.center)
        self.screen.blit(lvl_surf, lvl_rect)
        
        # Stars
        stars_x = 360
        # Check current potential stars in real time
        time_elapsed = 60.0 - self.round_time_left
        self.active_stars = self.ai.get_stars_and_score(self.hints_used_this_round, time_elapsed, is_correct=True)[0]
        # If not playing or correct, show what they got
        if self.round_state == "CORRECT":
            # total stars has already been updated
            pass
            
        for s in range(3):
            # If star is active, draw gold, else dark grey
            color = (255, 215, 0) if s < self.active_stars else (80, 80, 80)
            self.draw_star(self.screen, stars_x + s * 30, 36, 12, color)
            
        # Score
        sc_surf = self.font_header.render(f"SCORE: {self.score}", True, (255, 215, 0))
        sc_rect = sc_surf.get_rect(midright=(910, 35))
        self.screen.blit(sc_surf, sc_rect)
        
        # Timer (circular clock top right)
        timer_rect = pygame.Rect(930, 10, 50, 50)
        pygame.draw.circle(self.screen, (50, 50, 50), (955, 35), 25, 4)
        
        t_color = (34, 139, 34) # Green
        if self.round_time_left <= 10.0:
            t_color = (204, 34, 0) # Red
        elif self.round_time_left <= 30.0:
            t_color = (255, 140, 0) # Orange
            
        fraction = self.round_time_left / 60.0
        if fraction > 0:
            start_ang = math.pi / 2
            end_ang = start_ang + (2 * math.pi * fraction)
            pygame.draw.arc(self.screen, t_color, timer_rect, start_ang, end_ang, 5)
            
        digi_surf = self.font_timer.render(str(int(self.round_time_left)), True, (255, 255, 255))
        digi_rect = digi_surf.get_rect(center=(955, 35))
        self.screen.blit(digi_surf, digi_rect)
        
        # 2. Progress Bar
        pygame.draw.rect(self.screen, (50, 50, 50), (0, 70, 1024, 10))
        prog_w = int(1024 * ((self.round_num - 1) / 6.0))
        if self.round_state == "CORRECT":
            # Show next increment immediately on success
            prog_w = int(1024 * (self.round_num / 6.0))
        pygame.draw.rect(self.screen, (34, 139, 34), (0, 70, prog_w, 10))
        
        # 3. Prompt Text
        p_text = "Drag the words into the right order!"
        if self.is_listening:
            p_text = "Listening... Speak the sentence clearly!"
        p_surf = self.font_header.render(p_text, True, (120, 60, 20))
        p_rect = p_surf.get_rect(center=(650, 120))
        self.screen.blit(p_surf, p_rect)
        
        # 4. Chef Koko on Left
        self.draw_chef_koko(self.screen, 150, 480, self.chef_expression)
        
        # Chef Speech bubble
        if self.chef_bubble_text:
            self.draw_speech_bubble(self.screen, self.chef_bubble_text, self.font_small, 220, 310, 240, 90, 180, 430)
            
        # 5. Recipe Board
        self.draw_recipe_board(self.screen, self.board_rect)
        
        # 6. Slots & Snapped Tiles
        for slot in self.slots:
            is_hovered = False
            if self._drag_tile and slot.tile is None:
                mx, my = pygame.mouse.get_pos()
                scx, scy = slot.rect.center
                if math.hypot(mx - scx, my - scy) < 90:
                    is_hovered = True
                    
            if slot.tile is None:
                # Empty slot
                bg_c = (200, 235, 200) if is_hovered else (255, 248, 220)
                border_c = (34, 139, 34) if is_hovered else (120, 60, 20)
                border_w = 3 if is_hovered else 2
                
                pygame.draw.rect(self.screen, bg_c, slot.rect, border_radius=14)
                pygame.draw.rect(self.screen, border_c, slot.rect, width=border_w, border_radius=14)
                
                num_s = self.font_medium.render(str(slot.index + 1), True, (180, 150, 120))
                num_r = num_s.get_rect(center=slot.rect.center)
                self.screen.blit(num_s, num_r)
                
        # 7. Hint message bar
        if self.hint_text:
            h_rect = pygame.Rect(300, 620, 690, 40)
            pygame.draw.rect(self.screen, (255, 250, 205), h_rect, border_radius=8) # pale yellow bar
            pygame.draw.rect(self.screen, (255, 215, 0), h_rect, width=2, border_radius=8)
            
            hint_surf = self.font_medium.render(self.hint_text, True, (120, 60, 20))
            hint_rect = hint_surf.get_rect(center=h_rect.center)
            self.screen.blit(hint_surf, hint_rect)
            
        # 8. Render buttons
        # Bottom left: MIC (only if supported)
        if self.mic_supported:
            btn_mic_bg = (255, 100, 160) if self.is_listening else (30, 77, 140)
            btn_mic_hover = (255, 140, 180) if self.is_listening else (50, 100, 180)
            self.btn_mic.bg_color = btn_mic_bg
            self.btn_mic.hover_color = btn_mic_hover
            self.btn_mic.draw(self.screen, self.font_medium)
            
        # End game button in red
        self.btn_end.draw(self.screen, self.font_medium)
            
        # Bottom right
        self.btn_reset.draw(self.screen, self.font_medium)
        
        # Hint button text shows count
        h_left = 3 - self.hints_used_this_round
        self.btn_hint.text = f"HINT ({h_left})"
        self.btn_hint.draw(self.screen, self.font_medium, active=(h_left > 0))
        
        # Check button enabled only when all slots filled
        all_filled = all(slot.tile is not None for slot in self.slots)
        self.btn_check.draw(self.screen, self.font_medium, active=all_filled)
        
        # 9. Tiles (Bank & Snapped)
        # Render non-dragging tiles first, then dragging one on top
        for tile in self.tiles:
            if not tile.is_dragging:
                self.draw_tile(self.screen, tile, self.font_medium)
                
        if self._drag_tile:
            self.draw_tile(self.screen, self._drag_tile, self.font_medium)
            
        # 10. Confetti if correct
        if self.round_state == "CORRECT":
            for p in self.confetti:
                p.draw(self.screen)
            # Overlay correct banner
            overlay = pygame.Surface((1024, 768), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 80))
            self.screen.blit(overlay, (0, 0))
            
            banner = pygame.Rect(200, 260, 624, 180)
            pygame.draw.rect(self.screen, (34, 139, 34), banner, border_radius=20)
            pygame.draw.rect(self.screen, (255, 215, 0), banner, width=5, border_radius=20)
            
            c_surf = self.font_title.render("CORRECT!", True, (255, 255, 255))
            c_rect = c_surf.get_rect(center=(512, 320))
            self.screen.blit(c_surf, c_rect)
            
            p_surf = self.font_header.render(f"+{300 if self.active_stars == 3 else (120 if self.active_stars == 2 else 30)} Points!", True, (255, 215, 0))
            p_rect = p_surf.get_rect(center=(512, 380))
            self.screen.blit(p_surf, p_rect)
            
        # 11. Red flash overlay if wrong
        if self.wrong_flash_timer > 0:
            flash = pygame.Surface((1024, 768), pygame.SRCALPHA)
            flash.fill((204, 34, 0, 100)) # CC2200 alpha 100
            self.screen.blit(flash, (0, 0))
            
        # 12. Timeout overlay
        if self.round_state == "TIMEOUT":
            overlay = pygame.Surface((1024, 768), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 100))
            self.screen.blit(overlay, (0, 0))
            
            banner = pygame.Rect(200, 280, 624, 150)
            pygame.draw.rect(self.screen, (204, 34, 0), banner, border_radius=20)
            pygame.draw.rect(self.screen, (255, 215, 0), banner, width=5, border_radius=20)
            
            to_surf = self.font_title.render("TIME IS UP!", True, (255, 255, 255))
            to_rect = to_surf.get_rect(center=(512, 335))
            self.screen.blit(to_surf, to_rect)
            
            sub_surf = self.font_header.render("Keep practicing! Next round starting...", True, (255, 255, 255))
            sub_rect = sub_surf.get_rect(center=(512, 390))
            self.screen.blit(sub_surf, sub_rect)

    def _d_results(self):
        # Chef celebrating
        self.draw_chef_koko(self.screen, 180, 480, "CELEBRATE")
        
        # Results Card
        card = pygame.Rect(280, 100, 520, 520)
        pygame.draw.rect(self.screen, (255, 248, 220), card, border_radius=15)
        pygame.draw.rect(self.screen, (120, 60, 20), card, width=4, border_radius=15)
        
        # Title
        t_surf = self.font_title.render("Cooking Complete!", True, (255, 140, 0))
        t_rect = t_surf.get_rect(center=(540, 150))
        self.screen.blit(t_surf, t_rect)
        
        # Score Box
        s_box = pygame.Rect(440, 190, 200, 65)
        pygame.draw.rect(self.screen, (34, 139, 34), s_box, border_radius=12)
        score_surf = self.font_header.render(f"{self.score} PTS", True, (255, 255, 255))
        score_rect = score_surf.get_rect(center=s_box.center)
        self.screen.blit(score_surf, score_rect)
        
        # Stars gathered
        stars_cx = 540
        for s in range(3):
            # Visual stars
            color = (255, 215, 0) if (self.total_stars >= (s + 1) * 4) else (180, 180, 180) # scale stars roughly
            # To make it simple: just draw 3 large stars!
            # Let's count stars: if total_stars >= 12 -> 3 stars, >= 6 -> 2 stars, >= 1 -> 1 star
            earned_stars = 1
            if self.total_stars >= 14:
                earned_stars = 3
            elif self.total_stars >= 7:
                earned_stars = 2
            elif self.total_stars == 0:
                earned_stars = 0
                
            color = (255, 215, 0) if s < earned_stars else (180, 180, 180)
            self.draw_star(self.screen, stars_cx - 45 + s * 45, 290, 20, color)
            
        # Stats table
        stats = [
            ("Rounds Played:", f"{self.rounds_completed}/6"),
            ("Correct Sentences:", str(self.session_correct)),
            ("Mistakes / Timeouts:", str(self.session_mistakes))
        ]
        
        start_y = 340
        for label, val in stats:
            l_surf = self.font_medium.render(label, True, (120, 60, 20))
            self.screen.blit(l_surf, (330, start_y))
            
            v_surf = self.font_header.render(val, True, (30, 77, 140))
            self.screen.blit(v_surf, (620, start_y - 5))
            start_y += 50
            
        # Personalized message
        total_rounds = self.rounds_completed if self.rounds_completed > 0 else 1
        ratio = self.session_correct / float(total_rounds)
        if ratio >= 0.8:
            msg = f"Amazing, {self.pname}! You are a star chef!"
        elif ratio >= 0.5:
            msg = f"Great job, {self.pname}! Keep practising!"
        else:
            msg = f"Good try, {self.pname}! Try again!"
            
        msg_surf = self.font_medium.render(msg, True, (106, 13, 189))
        msg_rect = msg_surf.get_rect(center=(540, 510))
        self.screen.blit(msg_surf, msg_rect)
        
        # Buttons
        self.btn_play_again.draw(self.screen, self.font_medium)
        self.btn_view_leaders.draw(self.screen, self.font_medium)

    def _d_leaderboard(self):
        # Leaderboard Card
        card = pygame.Rect(200, 80, 624, 580)
        pygame.draw.rect(self.screen, (106, 13, 189), card, border_radius=20) # Purple
        pygame.draw.rect(self.screen, (255, 215, 0), card, width=4, border_radius=20) # Gold border
        
        # Title
        t_surf = self.font_header.render("Sentence Kitchen Leaderboard", True, (255, 215, 0))
        t_rect = t_surf.get_rect(center=(512, 130))
        self.screen.blit(t_surf, t_rect)
        
        # Session Stats Row
        stat_box = pygame.Rect(230, 175, 564, 75)
        pygame.draw.rect(self.screen, (255, 248, 220), stat_box, border_radius=10)
        pygame.draw.rect(self.screen, (120, 60, 20), stat_box, width=2, border_radius=10)
        
        # Stats text (Using font_small to ensure all session stats fit inside the box)
        sess_text = f"Last Run: Score: {self.score} | Correct: {self.session_correct} | Mistakes: {self.session_mistakes} | Stars: {self.total_stars}"
        s_surf = self.font_small.render(sess_text, True, (120, 60, 20))
        s_rect = s_surf.get_rect(center=stat_box.center)
        self.screen.blit(s_surf, s_rect)
        
        # All-time leaderboard header
        h_surf = self.font_header.render("All-Time Top Stars", True, (255, 255, 255))
        self.screen.blit(h_surf, (240, 275))
        
        # Fetch Top 4 Players
        top_players = database.get_high_scores(limit=4)
        
        start_y = 325
        medals = [
            ("1", (255, 215, 0)), # Gold
            ("2", (192, 192, 192)), # Silver
            ("3", (205, 127, 50)), # Bronze
            ("4", (150, 150, 150)) # Copper/grey
        ]
        
        for idx, player in enumerate(top_players):
            m_text, m_color = medals[idx]
            
            # Medal Circle
            pygame.draw.circle(self.screen, m_color, (260, start_y + 20), 16)
            m_num = self.font_medium.render(m_text, True, (0, 0, 0))
            mn_rect = m_num.get_rect(center=(260, start_y + 20))
            self.screen.blit(m_num, mn_rect)
            
            # Name (Truncated to 12 chars to prevent overlapping level badge)
            disp_name = player['name']
            if len(disp_name) > 12:
                disp_name = disp_name[:10] + ".."
            name_text = self.font_header.render(disp_name, True, (255, 248, 220))
            self.screen.blit(name_text, (300, start_y))
            
            # Level Badge
            lvl_names = {1: "Easy", 2: "Med", 3: "Hard"}
            l_badge = lvl_names.get(player['current_level'], "Easy")
            lbl_surf = self.font_small.render(f"Lv {l_badge}", True, (255, 255, 255))
            pygame.draw.rect(self.screen, (0, 128, 128), (460, start_y + 5, 80, 28), border_radius=6)
            self.screen.blit(lbl_surf, lbl_surf.get_rect(center=(500, start_y + 19)))
            
            # Games played (Using font_small and moving to 560 to prevent overlap with score)
            gp_surf = self.font_small.render(f"{player['games_played']} games", True, (200, 200, 200))
            self.screen.blit(gp_surf, (560, start_y + 7))
            
            # Score (Right-aligned to 790 to prevent overflowing card boundary)
            score_text = self.font_header.render(f"{player['total_score']} PTS", True, (255, 215, 0))
            score_rect = score_text.get_rect(right=790, y=start_y)
            self.screen.blit(score_text, score_rect)
            
            start_y += 55
            
        # CSV Export status message
        if self.csv_export_message:
            # Draw temporary export dialog/banner
            eb_rect = pygame.Rect(230, 525, 564, 40)
            pygame.draw.rect(self.screen, (200, 235, 200), eb_rect, border_radius=8)
            pygame.draw.rect(self.screen, (34, 139, 34), eb_rect, width=2, border_radius=8)
            
            eb_surf = self.font_small.render(self.csv_export_message, True, (20, 80, 20))
            eb_rect_t = eb_surf.get_rect(center=eb_rect.center)
            self.screen.blit(eb_surf, eb_rect_t)
            
            # Reset message after 4 seconds
            if time.time() - self.csv_export_timer > 4.0:
                self.csv_export_message = ""
                
        # Buttons
        self.btn_export_csv.draw(self.screen, self.font_medium)
        self.btn_home.draw(self.screen, self.font_medium)

    # Main application loop
    def run(self):
        running = True
        while running:
            self.clock.tick(60)
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                    
                # Esc to exit game
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    running = False
                    
                else:
                    if self.state == S_MENU:
                        self._e_menu(event)
                    elif self.state == S_INSTR:
                        self._e_instr(event)
                    elif self.state == S_PLAY:
                        self._e_play(event)
                    elif self.state == S_RESULTS:
                        self._e_results(event)
                    elif self.state == S_LEADERBOARD:
                        self._e_leaderboard(event)
                        
            self.update()
            self.draw()
            
        pygame.quit()
        sys.exit()

if __name__ == "__main__":
    game = Game()
    game.run()
