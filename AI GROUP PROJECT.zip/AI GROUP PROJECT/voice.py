# voice.py
import queue
import threading
import os
import sys
import subprocess
import pygame
import difflib

# Try to import speech recognition and audio libraries
try:
    import speech_recognition as sr
    import pyaudio
    _mic_available = True
except Exception as e:
    _mic_available = False

try:
    import pyttsx3
    _tts_available = True
except Exception as e:
    print("Failed to import pyttsx3:", e)
    _tts_available = (sys.platform == 'darwin')

# Global TTS background thread instance
_tts_thread = None

class TTSThread(threading.Thread):
    def __init__(self):
        super().__init__()
        self.daemon = True
        self.queue = queue.Queue()
        self.engine = None
        self.initialized = False
        self.process = None

    def run(self):
        is_mac = (sys.platform == 'darwin')
        if not is_mac and not _tts_available:
            return
            
        if is_mac:
            self.initialized = True
        else:
            try:
                self.engine = pyttsx3.init()
                # Set rate to 130 WPM (age-appropriate for 4-6 year olds)
                self.engine.setProperty('rate', 130)
                
                # Select English Male voice (highest quality and clarity)
                voices = self.engine.getProperty('voices')
                selected_voice = None
                
                # Filter for English voices first
                english_voices = []
                for v in voices:
                    is_eng = False
                    langs = getattr(v, 'languages', [])
                    if langs:
                        is_eng = any('en' in str(lang).lower() for lang in langs)
                    if not is_eng:
                        # Fallback check on ID or name strings
                        is_eng = 'en' in v.id.lower() or 'english' in v.name.lower() or 'en_' in v.id or 'en-' in v.id
                    if is_eng:
                        english_voices.append(v)
                        
                if not english_voices:
                    english_voices = voices # Fallback to all if no English matches found
                    
                # Find a male voice among the English voices
                for v in english_voices:
                    gender = str(getattr(v, 'gender', '')).lower()
                    name = v.name.lower()
                    # Prioritize 'alex' or 'daniel' since they are excellent clear male English voices on Mac
                    if 'alex' in name or 'daniel' in name:
                        selected_voice = v.id
                        break
                    elif gender == 'male':
                        selected_voice = v.id
                        break
                    elif any(m_name in name for m_name in ['male', 'david', 'fred', 'bruce', 'tom']):
                        selected_voice = v.id
                        break
                        
                # Fallback to the first English voice if no Male English found
                if not selected_voice and english_voices:
                    selected_voice = english_voices[0].id
                    
                if selected_voice:
                    self.engine.setProperty('voice', selected_voice)
                    
                self.initialized = True
            except Exception as e:
                print("TTS Engine failed to initialize:", e)
                self.initialized = False
                return

        while True:
            text = self.queue.get()
            if text is None:
                break
            try:
                # Pause background music if it is playing (and not overridden by active mic)
                music_was_playing = False
                try:
                    if pygame.mixer.get_init() and pygame.mixer.music.get_busy() and not _mic_active:
                        pygame.mixer.music.pause()
                        music_was_playing = True
                except Exception:
                    pass

                global _is_speaking
                _is_speaking = True
                if is_mac:
                    # Speak using macOS say command natively with the high-quality male voice 'Daniel'
                    p = subprocess.Popen(['say', '-v', 'Daniel', '-r', '130', text])
                    self.process = p
                    p.wait()
                    
                    if p.returncode != 0 and self.process is not None:
                        p2 = subprocess.Popen(['say', '-r', '130', text])
                        self.process = p2
                        p2.wait()
                        
                    self.process = None
                else:
                    self.engine.say(text)
                    self.engine.runAndWait()
                _is_speaking = False

                # Resume background music if it was paused for speech (and mic is not active)
                if music_was_playing and not _mic_active:
                    try:
                        pygame.mixer.music.unpause()
                    except Exception:
                        pass
            except Exception as e:
                print("TTS Speak error:", e)
                _is_speaking = False
            self.queue.task_done()

    def stop(self):
        # Clear the queue to prevent further speech
        while not self.queue.empty():
            try:
                self.queue.get_nowait()
                self.queue.task_done()
            except queue.Empty:
                break
                
        # Terminate active say process on Mac
        if self.process:
            try:
                self.process.terminate()
            except Exception:
                pass
            self.process = None
            
        # Stop pyttsx3 engine
        if self.engine:
            try:
                self.engine.stop()
            except Exception:
                pass

_mic_active = False
_is_speaking = False

def set_mic_active(active):
    """Sets microphone active state, pausing music completely while mic is open."""
    global _mic_active
    _mic_active = active
    try:
        if pygame.mixer.get_init():
            if active:
                pygame.mixer.music.pause()
            else:
                pygame.mixer.music.unpause()
    except Exception:
        pass

def is_speaking():
    """Checks if Chef Koko is currently speaking."""
    global _is_speaking
    return _is_speaking

def init_voice():
    """Initializes the background voice system."""
    global _tts_thread
    if _tts_available and _tts_thread is None:
        _tts_thread = TTSThread()
        _tts_thread.start()

def speak(text):
    """Speaks the text aloud in a background thread (non-blocking)."""
    init_voice()
    if _tts_thread:
        # Wait briefly for background engine boot if it's the very first call
        import time
        start_wait = time.time()
        while not _tts_thread.initialized and _tts_thread.is_alive() and (time.time() - start_wait < 4.0):
            time.sleep(0.02)
            
        if _tts_thread.initialized:
            # Clear queue to cancel older spoken messages and prioritize the latest
            while not _tts_thread.queue.empty():
                try:
                    _tts_thread.queue.get_nowait()
                    _tts_thread.queue.task_done()
                except queue.Empty:
                    break
            _tts_thread.queue.put(text)
            return
            
    print(f"[Silent TTS] Chef Koko says: '{text}'")

def stop():
    """Stops any active speech and clears the speech queue."""
    if _tts_thread:
        _tts_thread.stop()

def is_mic_available():
    """Checks if speech recognition and microphone are available."""
    if not _mic_available:
        return False
    # Double check if a recording device actually exists
    try:
        import speech_recognition as sr
        m = sr.Microphone()
        # Test if we can list mics
        sr.Microphone.list_microphone_names()
        return True
    except Exception:
        return False

class ListenThread(threading.Thread):
    def __init__(self, event_id):
        super().__init__()
        self.event_id = event_id
        self.daemon = True

    def run(self):
        if not _mic_available:
            pygame.event.post(pygame.event.Event(self.event_id, {"text": "Microphone libraries missing", "success": False}))
            return
            
        try:
            import time
            # Give TTS thread a brief moment to pick up the speak command and set _is_speaking
            time.sleep(0.25)
            # Wait for Koko to finish speaking before listening, to prevent audio feedback/calibration interference
            start_wait = time.time()
            while is_speaking() and (time.time() - start_wait < 4.0):
                time.sleep(0.05)
                
            import speech_recognition as sr
            r = sr.Recognizer()
            with sr.Microphone() as source:
                # Adjust for ambient noise briefly in a quieter window
                r.adjust_for_ambient_noise(source, duration=0.5)
                # Listen with longer timeout for children and hard sentences
                audio = r.listen(source, timeout=8, phrase_time_limit=10)
                
            # Recognize speech using Google Speech Recognition
            text = r.recognize_google(audio)
            pygame.event.post(pygame.event.Event(self.event_id, {"text": text, "success": True}))
        except sr.WaitTimeoutError:
            pygame.event.post(pygame.event.Event(self.event_id, {"text": "No speech heard", "success": False}))
        except sr.UnknownValueError:
            pygame.event.post(pygame.event.Event(self.event_id, {"text": "Could not understand audio", "success": False}))
        except Exception as e:
            pygame.event.post(pygame.event.Event(self.event_id, {"text": str(e), "success": False}))

def start_listening(event_id):
    """Spawns a background thread to listen to voice input, returning result via Pygame event."""
    thread = ListenThread(event_id)
    thread.start()

def check_word_match(spoken, target):
    """
    Checks if the spoken words match the target sentence.
    Uses fuzzy matching on individual words to account for minor speech variations,
    slight child mispronunciations, or speech-to-text transcript variations.
    75% match threshold for acceptance (ignores case and punctuation).
    """
    spoken_clean = "".join([c.lower() for c in spoken if c.isalnum() or c.isspace()]).strip()
    target_clean = "".join([c.lower() for c in target if c.isalnum() or c.isspace()]).strip()
    
    spoken_words = spoken_clean.split()
    target_words = target_clean.split()
    
    if not target_words:
        return False, 0.0
        
    matched = 0
    temp_spoken = spoken_words.copy()
    for word in target_words:
        best_match = None
        best_ratio = 0.0
        for sw in temp_spoken:
            if sw == word:
                best_match = sw
                best_ratio = 1.0
                break
            r = difflib.SequenceMatcher(None, word, sw).ratio()
            if r > best_ratio:
                best_ratio = r
                best_match = sw
                
        # If we have a good match (75% or higher similarity), count it
        if best_ratio >= 0.75:
            matched += 1
            temp_spoken.remove(best_match)
            
    match_ratio = matched / len(target_words)
    # Child-friendly: allow a match if at least 75% of words are correct/fuzzy-matched
    return match_ratio >= 0.75, match_ratio
